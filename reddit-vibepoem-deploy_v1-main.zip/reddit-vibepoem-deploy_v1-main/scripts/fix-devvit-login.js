#!/usr/bin/env node

/**
 * Automated Devvit CLI Login Fix Script
 * This script attempts to automatically resolve common login issues
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

class DevvitLoginFixer {
  constructor() {
    this.fixes = [];
    this.errors = [];
  }

  log(message, type = 'info') {
    const colors = {
      info: '\x1b[36m',
      success: '\x1b[32m',
      warning: '\x1b[33m',
      error: '\x1b[31m',
      reset: '\x1b[0m'
    };
    
    console.log(`${colors[type]}${message}${colors.reset}`);
  }

  execSafe(command, description) {
    try {
      this.log(`🔧 ${description}...`, 'info');
      const result = execSync(command, { encoding: 'utf8', stdio: 'pipe' });
      this.log(`✅ ${description} - Success`, 'success');
      this.fixes.push(description);
      return result.trim();
    } catch (error) {
      this.log(`❌ ${description} - Failed: ${error.message}`, 'error');
      this.errors.push({ description, error: error.message });
      return null;
    }
  }

  async fixProxyIssues() {
    this.log('\n🌐 Fixing Proxy Issues...', 'info');
    
    // Clear npm proxy settings
    this.execSafe('npm config delete proxy', 'Clear npm HTTP proxy');
    this.execSafe('npm config delete https-proxy', 'Clear npm HTTPS proxy');
    
    // Check environment variables
    const envVars = ['HTTP_PROXY', 'HTTPS_PROXY', 'http_proxy', 'https_proxy'];
    for (const envVar of envVars) {
      if (process.env[envVar]) {
        this.log(`⚠️  Environment variable ${envVar} is set: ${process.env[envVar]}`, 'warning');
        this.log(`   Consider running: unset ${envVar}`, 'info');
      }
    }
  }

  async updateDevvitCLI() {
    this.log('\n📦 Updating Devvit CLI...', 'info');
    
    // Uninstall old version
    this.execSafe('npm uninstall -g @devvit/cli', 'Uninstall old Devvit CLI');
    
    // Install latest version
    this.execSafe('npm install -g @devvit/cli@latest', 'Install latest Devvit CLI');
    
    // Verify installation
    const version = this.execSafe('npx devvit --version', 'Verify Devvit CLI installation');
    if (version) {
      this.log(`✅ Devvit CLI version: ${version}`, 'success');
    }
  }

  async clearCache() {
    this.log('\n🧹 Clearing Caches...', 'info');
    
    // Clear npm cache
    this.execSafe('npm cache clean --force', 'Clear npm cache');
    
    // Clear Devvit session
    this.execSafe('npx devvit logout', 'Clear existing Devvit session');
    
    // Clear potential credential files
    const homeDir = require('os').homedir();
    const devvitConfigPaths = [
      path.join(homeDir, '.devvit'),
      path.join(homeDir, '.config', 'devvit')
    ];
    
    for (const configPath of devvitConfigPaths) {
      if (fs.existsSync(configPath)) {
        try {
          fs.rmSync(configPath, { recursive: true, force: true });
          this.log(`✅ Cleared Devvit config: ${configPath}`, 'success');
          this.fixes.push(`Clear Devvit config: ${configPath}`);
        } catch (error) {
          this.log(`⚠️  Could not clear ${configPath}: ${error.message}`, 'warning');
        }
      }
    }
  }

  async attemptLogin() {
    this.log('\n🔐 Attempting Devvit Login...', 'info');
    
    try {
      // First try normal login
      this.log('Trying automatic login...', 'info');
      const loginResult = this.execSafe('timeout 30 npx devvit login', 'Automatic login');
      
      if (loginResult) {
        // Check if login was successful
        const whoami = this.execSafe('npx devvit whoami', 'Check login status');
        if (whoami && !whoami.includes('not logged in')) {
          this.log(`🎉 Login successful! Logged in as: ${whoami}`, 'success');
          return true;
        }
      }
    } catch (error) {
      this.log('Automatic login failed, trying manual method...', 'warning');
    }
    
    try {
      // Try manual login URL
      this.log('Getting manual login URL...', 'info');
      const manualLogin = this.execSafe('npx devvit login --no-open', 'Get manual login URL');
      
      if (manualLogin) {
        this.log('📋 Manual login instructions:', 'info');
        this.log(manualLogin, 'info');
        this.log('\n💡 Please:', 'info');
        this.log('1. Copy the URL above', 'info');
        this.log('2. Open it in your browser', 'info');
        this.log('3. Complete the Reddit OAuth flow', 'info');
        this.log('4. Return here and run: npx devvit whoami', 'info');
        return 'manual';
      }
    } catch (error) {
      this.log(`Manual login also failed: ${error.message}`, 'error');
    }
    
    return false;
  }

  async checkEnvironment() {
    this.log('\n🔍 Environment Check...', 'info');
    
    // Check Node.js version
    const nodeVersion = process.version;
    this.log(`Node.js version: ${nodeVersion}`, 'info');
    
    const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
    if (majorVersion < 18) {
      this.log('⚠️  Node.js version might be too old. Devvit requires Node.js 18+', 'warning');
      this.log('   Consider updating Node.js: https://nodejs.org/', 'info');
    } else {
      this.log('✅ Node.js version is compatible', 'success');
    }
    
    // Check npm version
    const npmVersion = this.execSafe('npm --version', 'Check npm version');
    if (npmVersion) {
      this.log(`npm version: ${npmVersion}`, 'info');
    }
    
    // Check network connectivity
    this.log('Testing network connectivity...', 'info');
    const curlTest = this.execSafe('curl -I --connect-timeout 5 https://www.reddit.com', 'Test Reddit connectivity');
    if (curlTest && curlTest.includes('200')) {
      this.log('✅ Can reach Reddit servers', 'success');
    } else {
      this.log('❌ Cannot reach Reddit servers - check network/firewall', 'error');
    }
  }

  generateReport() {
    this.log('\n📊 TROUBLESHOOTING REPORT', 'info');
    this.log('='.repeat(50), 'info');
    
    if (this.fixes.length > 0) {
      this.log('✅ Successful fixes applied:', 'success');
      this.fixes.forEach(fix => this.log(`   • ${fix}`, 'success'));
    }
    
    if (this.errors.length > 0) {
      this.log('\n❌ Issues encountered:', 'error');
      this.errors.forEach(error => this.log(`   • ${error.description}: ${error.error}`, 'error'));
    }
    
    this.log('\n💡 Next Steps:', 'info');
    this.log('1. If login still fails, try from a different network', 'info');
    this.log('2. Check if your Reddit account is in good standing', 'info');
    this.log('3. Contact your IT department if behind corporate firewall', 'info');
    this.log('4. Try the manual login URL method if provided above', 'info');
    
    this.log('\n🔗 Useful Commands:', 'info');
    this.log('   npx devvit whoami          - Check login status', 'info');
    this.log('   npx devvit login --verbose - Login with detailed output', 'info');
    this.log('   npx devvit login --no-open - Get manual login URL', 'info');
    this.log('   npx devvit logout          - Logout and start fresh', 'info');
  }

  async runAll() {
    this.log('🚀 Starting Devvit CLI Login Fix...', 'info');
    this.log('This will attempt to resolve common login issues\n', 'info');
    
    await this.checkEnvironment();
    await this.fixProxyIssues();
    await this.clearCache();
    await this.updateDevvitCLI();
    
    const loginResult = await this.attemptLogin();
    
    this.generateReport();
    
    if (loginResult === true) {
      this.log('\n🎉 SUCCESS! Devvit CLI login is now working!', 'success');
    } else if (loginResult === 'manual') {
      this.log('\n⚠️  Manual login required - follow the instructions above', 'warning');
    } else {
      this.log('\n❌ Login still failing - see report above for next steps', 'error');
    }
  }
}

// Run the fixer if called directly
if (require.main === module) {
  const fixer = new DevvitLoginFixer();
  fixer.runAll().catch(console.error);
}

module.exports = DevvitLoginFixer;