#!/usr/bin/env node

/**
 * Network Diagnostics for Devvit CLI Connection Issues
 * This script checks common network configuration issues that prevent Devvit CLI login
 */

const { execSync, spawn } = require('child_process');
const https = require('https');
const http = require('http');
const url = require('url');

class NetworkDiagnostics {
  constructor() {
    this.results = {
      proxy: {},
      connectivity: {},
      dns: {},
      certificates: {},
      devvit: {}
    };
  }

  log(message, type = 'info') {
    const colors = {
      info: '\x1b[36m',    // Cyan
      success: '\x1b[32m', // Green
      warning: '\x1b[33m', // Yellow
      error: '\x1b[31m',   // Red
      reset: '\x1b[0m'     // Reset
    };
    
    console.log(`${colors[type]}${message}${colors.reset}`);
  }

  async checkProxySettings() {
    this.log('\n🔍 Checking Proxy Settings...', 'info');
    
    try {
      // Check npm proxy settings
      const npmProxy = this.execSafe('npm config get proxy');
      const npmHttpsProxy = this.execSafe('npm config get https-proxy');
      const npmRegistry = this.execSafe('npm config get registry');
      
      this.results.proxy.npm = {
        proxy: npmProxy || 'not set',
        httpsProxy: npmHttpsProxy || 'not set',
        registry: npmRegistry || 'default'
      };
      
      // Check environment variables
      const envProxy = process.env.HTTP_PROXY || process.env.http_proxy;
      const envHttpsProxy = process.env.HTTPS_PROXY || process.env.https_proxy;
      const envNoProxy = process.env.NO_PROXY || process.env.no_proxy;
      
      this.results.proxy.environment = {
        httpProxy: envProxy || 'not set',
        httpsProxy: envHttpsProxy || 'not set',
        noProxy: envNoProxy || 'not set'
      };
      
      // Display results
      this.log('📋 NPM Proxy Configuration:', 'info');
      this.log(`  HTTP Proxy: ${this.results.proxy.npm.proxy}`);
      this.log(`  HTTPS Proxy: ${this.results.proxy.npm.httpsProxy}`);
      this.log(`  Registry: ${this.results.proxy.npm.registry}`);
      
      this.log('📋 Environment Proxy Variables:', 'info');
      this.log(`  HTTP_PROXY: ${this.results.proxy.environment.httpProxy}`);
      this.log(`  HTTPS_PROXY: ${this.results.proxy.environment.httpsProxy}`);
      this.log(`  NO_PROXY: ${this.results.proxy.environment.noProxy}`);
      
      // Check if proxy is causing issues
      if (npmProxy !== 'not set' || npmHttpsProxy !== 'not set' || envProxy || envHttpsProxy) {
        this.log('⚠️  Proxy detected - this might interfere with Devvit CLI authentication', 'warning');
        this.log('💡 Try temporarily disabling proxy:', 'info');
        this.log('   npm config delete proxy');
        this.log('   npm config delete https-proxy');
        this.log('   unset HTTP_PROXY HTTPS_PROXY');
      } else {
        this.log('✅ No proxy configuration detected', 'success');
      }
      
    } catch (error) {
      this.log(`❌ Error checking proxy settings: ${error.message}`, 'error');
    }
  }

  async checkConnectivity() {
    this.log('\n🌐 Checking Network Connectivity...', 'info');
    
    const testUrls = [
      'https://www.reddit.com',
      'https://oauth.reddit.com',
      'https://api.reddit.com',
      'https://developers.reddit.com',
      'https://registry.npmjs.org'
    ];
    
    for (const testUrl of testUrls) {
      try {
        const result = await this.testHttpsConnection(testUrl);
        this.results.connectivity[testUrl] = result;
        
        if (result.success) {
          this.log(`✅ ${testUrl} - OK (${result.statusCode})`, 'success');
        } else {
          this.log(`❌ ${testUrl} - Failed: ${result.error}`, 'error');
        }
      } catch (error) {
        this.log(`❌ ${testUrl} - Error: ${error.message}`, 'error');
        this.results.connectivity[testUrl] = { success: false, error: error.message };
      }
    }
  }

  async checkDNS() {
    this.log('\n🔍 Checking DNS Resolution...', 'info');
    
    const domains = [
      'reddit.com',
      'oauth.reddit.com',
      'api.reddit.com',
      'developers.reddit.com'
    ];
    
    for (const domain of domains) {
      try {
        const result = await this.resolveDNS(domain);
        this.results.dns[domain] = result;
        
        if (result.success) {
          this.log(`✅ ${domain} resolves to: ${result.addresses.join(', ')}`, 'success');
        } else {
          this.log(`❌ ${domain} - DNS resolution failed: ${result.error}`, 'error');
        }
      } catch (error) {
        this.log(`❌ ${domain} - DNS error: ${error.message}`, 'error');
      }
    }
  }

  async checkDevvitCLI() {
    this.log('\n🔧 Checking Devvit CLI...', 'info');
    
    try {
      // Check if Devvit CLI is installed
      const version = this.execSafe('npx devvit --version');
      if (version) {
        this.log(`✅ Devvit CLI version: ${version.trim()}`, 'success');
        this.results.devvit.version = version.trim();
      } else {
        this.log('❌ Devvit CLI not found', 'error');
        return;
      }
      
      // Check current auth status
      try {
        const whoami = this.execSafe('npx devvit whoami');
        if (whoami && !whoami.includes('not logged in')) {
          this.log(`✅ Already logged in as: ${whoami.trim()}`, 'success');
          this.results.devvit.loggedIn = true;
          this.results.devvit.user = whoami.trim();
        } else {
          this.log('ℹ️  Not currently logged in', 'info');
          this.results.devvit.loggedIn = false;
        }
      } catch (error) {
        this.log('ℹ️  Not currently logged in', 'info');
        this.results.devvit.loggedIn = false;
      }
      
      // Check for common CLI issues
      this.log('\n🔍 Checking for common CLI issues...', 'info');
      
      // Check Node.js version
      const nodeVersion = process.version;
      this.log(`Node.js version: ${nodeVersion}`);
      
      const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
      if (majorVersion < 18) {
        this.log('⚠️  Node.js version might be too old. Devvit requires Node.js 18+', 'warning');
      } else {
        this.log('✅ Node.js version is compatible', 'success');
      }
      
    } catch (error) {
      this.log(`❌ Error checking Devvit CLI: ${error.message}`, 'error');
    }
  }

  async checkCertificates() {
    this.log('\n🔒 Checking SSL Certificates...', 'info');
    
    const testUrl = 'https://oauth.reddit.com';
    
    try {
      const result = await this.checkSSLCertificate(testUrl);
      this.results.certificates[testUrl] = result;
      
      if (result.success) {
        this.log(`✅ SSL certificate for ${testUrl} is valid`, 'success');
        this.log(`   Issuer: ${result.issuer}`);
        this.log(`   Valid until: ${result.validTo}`);
      } else {
        this.log(`❌ SSL certificate issue for ${testUrl}: ${result.error}`, 'error');
      }
    } catch (error) {
      this.log(`❌ Error checking SSL certificate: ${error.message}`, 'error');
    }
  }

  // Helper methods
  execSafe(command) {
    try {
      return execSync(command, { encoding: 'utf8', stdio: 'pipe' }).toString().trim();
    } catch (error) {
      return null;
    }
  }

  testHttpsConnection(testUrl) {
    return new Promise((resolve) => {
      const parsedUrl = url.parse(testUrl);
      const options = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || 443,
        path: parsedUrl.path || '/',
        method: 'HEAD',
        timeout: 10000
      };

      const req = https.request(options, (res) => {
        resolve({
          success: true,
          statusCode: res.statusCode,
          headers: res.headers
        });
      });

      req.on('error', (error) => {
        resolve({
          success: false,
          error: error.message
        });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve({
          success: false,
          error: 'Connection timeout'
        });
      });

      req.end();
    });
  }

  resolveDNS(domain) {
    return new Promise((resolve) => {
      const dns = require('dns');
      dns.resolve4(domain, (err, addresses) => {
        if (err) {
          resolve({
            success: false,
            error: err.message
          });
        } else {
          resolve({
            success: true,
            addresses: addresses
          });
        }
      });
    });
  }

  checkSSLCertificate(testUrl) {
    return new Promise((resolve) => {
      const parsedUrl = url.parse(testUrl);
      const options = {
        hostname: parsedUrl.hostname,
        port: parsedUrl.port || 443,
        method: 'HEAD',
        timeout: 10000
      };

      const req = https.request(options, (res) => {
        const cert = res.connection.getPeerCertificate();
        resolve({
          success: true,
          issuer: cert.issuer.CN,
          subject: cert.subject.CN,
          validFrom: cert.valid_from,
          validTo: cert.valid_to
        });
      });

      req.on('error', (error) => {
        resolve({
          success: false,
          error: error.message
        });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve({
          success: false,
          error: 'SSL handshake timeout'
        });
      });

      req.end();
    });
  }

  generateReport() {
    this.log('\n📊 DIAGNOSTIC SUMMARY', 'info');
    this.log('='.repeat(50), 'info');
    
    // Proxy issues
    const hasProxy = this.results.proxy.npm?.proxy !== 'not set' || 
                    this.results.proxy.npm?.httpsProxy !== 'not set' ||
                    this.results.proxy.environment?.httpProxy !== 'not set' ||
                    this.results.proxy.environment?.httpsProxy !== 'not set';
    
    if (hasProxy) {
      this.log('⚠️  PROXY DETECTED - Likely cause of login issues', 'warning');
      this.log('   Solution: Temporarily disable proxy settings', 'info');
    }
    
    // Connectivity issues
    const connectivityIssues = Object.values(this.results.connectivity)
      .filter(result => !result.success).length;
    
    if (connectivityIssues > 0) {
      this.log(`❌ ${connectivityIssues} connectivity issues found`, 'error');
      this.log('   Check firewall/network restrictions', 'info');
    }
    
    // DNS issues
    const dnsIssues = Object.values(this.results.dns)
      .filter(result => !result.success).length;
    
    if (dnsIssues > 0) {
      this.log(`❌ ${dnsIssues} DNS resolution issues found`, 'error');
      this.log('   Check DNS settings or try different DNS server', 'info');
    }
    
    this.log('\n💡 RECOMMENDED ACTIONS:', 'info');
    
    if (hasProxy) {
      this.log('1. Temporarily disable proxy:', 'info');
      this.log('   npm config delete proxy', 'info');
      this.log('   npm config delete https-proxy', 'info');
      this.log('   unset HTTP_PROXY HTTPS_PROXY (in terminal)', 'info');
    }
    
    if (connectivityIssues > 0) {
      this.log('2. Check network/firewall settings', 'info');
      this.log('3. Try from a different network (mobile hotspot)', 'info');
    }
    
    this.log('4. Update Devvit CLI to latest version:', 'info');
    this.log('   npm install -g @devvit/cli@latest', 'info');
    
    this.log('5. Try alternative login methods:', 'info');
    this.log('   npx devvit logout && npx devvit login', 'info');
    this.log('   npx devvit login --no-open', 'info');
  }

  async runAll() {
    this.log('🚀 Starting Network Diagnostics for Devvit CLI...', 'info');
    this.log('This will help identify why Devvit CLI login is failing\n', 'info');
    
    await this.checkProxySettings();
    await this.checkConnectivity();
    await this.checkDNS();
    await this.checkCertificates();
    await this.checkDevvitCLI();
    
    this.generateReport();
    
    this.log('\n✅ Diagnostics complete!', 'success');
    this.log('If issues persist, share this output with the Devvit team.', 'info');
  }
}

// Run diagnostics if called directly
if (require.main === module) {
  const diagnostics = new NetworkDiagnostics();
  diagnostics.runAll().catch(console.error);
}

module.exports = NetworkDiagnostics;