# Daily Skinny Poem - Reddit Devvit App

A collaborative poetry creation app for Reddit communities, built with Devvit. Community members vote on key elements throughout the day to create a unique daily poem.

[![Built with Bolt.new](https://img.shields.io/badge/Built%20with-Bolt.new-blue?style=flat-square&logo=lightning)](https://bolt.new)

## 🎭 Features

- **Daily Collaborative Poetry**: Community creates poems through structured voting phases
- **Time-Based Phases**: Voting happens in 4-hour windows throughout the day (Eastern Time)
- **Mood-Driven Generation**: AI-powered poem generation based on community mood preferences
- **Archive System**: Browse and view all previously created poems
- **Rate Limiting**: Prevents spam while encouraging participation
- **Auto-Posting**: Automatically posts completed poems to the subreddit

## 📅 Daily Schedule (Eastern Time)

- **8AM-12PM**: Vote for Key Line (opening/closing line of poem)
- **12PM-4PM**: Vote for Key Word (repeated throughout poem)
- **4PM-8PM**: Set Poem Mood (happiness, energy, mystery, romance, darkness, nature)
- **8PM-9PM**: Poem Generation (AI creates the final poem)
- **9PM**: Daily Poem Published

## 🚀 Installation

1. **Prerequisites**
   - Node.js 18+ installed
   - Reddit account with developer access
   - Devvit CLI installed: `npm install -g @devvit/cli`

2. **Setup**
   ```bash
   # Clone the repository
   git clone <your-repo-url>
   cd reddit-vibepoem
   
   # Install dependencies
   npm install
   
   # Login to Devvit (requires Reddit OAuth)
   devvit login
   
   # Build the app
   npm run build
   
   # Upload to Reddit
   devvit upload
   
   # Install in your subreddit
   devvit install
   ```

3. **Configuration**
   - Set up OpenAI API key in app settings (optional, for image prompts)
   - Configure voting durations and rate limits as needed
   - Enable/disable auto-posting of completed poems

## 🛠️ Development

### Local Development
```bash
# Start local development server
npm run dev

# Run type checking
npm run type-check

# Run linting
npm run lint

# Build for production
npm run build
```

### WebContainer Development
If you're developing in a WebContainer environment (like StackBlitz):

```bash
# Mock development mode
npm run dev:mock

# Check memory usage
npm run memory-check

# Clean cache
npm run clean
```

### Troubleshooting
If you encounter Devvit CLI login issues:

```bash
# Run network diagnostics
node scripts/network-diagnostics.js

# Attempt automated fixes
node scripts/fix-devvit-login.js
```

## 🏗️ Architecture

### Core Components
- **VotingInterface**: Handles key line and key word voting
- **MoodVotingInterface**: Manages mood preference voting
- **PoemDisplay**: Shows completed poems with formatting
- **StorageManager**: Redis-based data persistence with caching
- **PoemGenerator**: AI-powered poem creation logic

### Data Flow
1. **Phase Detection**: Time-based phase management using Eastern Time
2. **Voting Sessions**: Redis-stored voting data with TTL
3. **Rate Limiting**: Per-user hourly vote limits
4. **Poem Generation**: Combines voting results into structured poems
5. **Archive Storage**: Long-term poem storage with metadata

### File Structure
```
src/
├── components/          # React-like UI components
├── utils/              # Core utilities and business logic
├── shared/             # Shared constants and utilities
├── types.ts            # TypeScript type definitions
└── main.tsx            # Main app entry point
```

## 🎨 Poem Structure

The "Skinny Poem" format follows this 11-line structure:
1. **Key Line** (community voted)
2. **Key Word** (community voted)
3. **Verb** (mood-influenced)
4. **Preposition** (mood-influenced)
5. **Noun/Adjective** (mood-influenced)
6. **Key Word** (repeated)
7. **Preposition** (mood-influenced)
8. **Adjective/Verb** (mood-influenced)
9. **Key Word** (repeated)
10. **Adjective/Noun** (mood-influenced)
11. **Key Line** (repeated, ending with period)

## 🔧 Configuration

### App Settings
- `openai_api_key`: OpenAI API key for image prompt generation
- `auto_post_enabled`: Automatically post completed poems
- `keyline_voting_duration`: Hours for key line voting (default: 4)
- `keyword_voting_duration`: Hours for key word voting (default: 4)
- `mood_voting_duration`: Hours for mood voting (default: 4)
- `max_votes_per_hour`: Rate limit per user (default: 10)

### Admin Functions
- **Simulate Current Phase**: Skip to next phase (moderators only)
- **Cleanup Expired Data**: Remove old voting sessions and cache

## 🔒 Security & Privacy

- **API Keys**: Stored securely using Devvit's secret management
- **Rate Limiting**: Prevents spam and abuse
- **Input Validation**: All user inputs are validated and sanitized
- **Error Handling**: Comprehensive error handling with user feedback
- **Data Retention**: Automatic cleanup of expired voting data

## 📊 Monitoring

The app includes built-in monitoring for:
- Memory usage optimization
- Cache performance
- Rate limit status
- Network connectivity issues
- Redis operation success rates

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Built with [Bolt.new](https://bolt.new)** - AI-powered full-stack development
- **Reddit Devvit Platform** - For providing the development framework
- **Community Contributors** - For participating in daily poem creation

## 📞 Support

- **Issues**: Report bugs and feature requests via GitHub Issues
- **Documentation**: Check the [Devvit Documentation](https://developers.reddit.com/docs)
- **Community**: Join the Reddit developer community for support

---

⚡ **Built with [Bolt.new](https://bolt.new)** - AI-powered full-stack development platform