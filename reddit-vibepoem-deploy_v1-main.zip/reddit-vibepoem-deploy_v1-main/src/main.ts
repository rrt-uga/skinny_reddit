import { Devvit, useState, useAsync, useInterval } from '@devvit/public-api';
import { StorageManager } from './utils/storage.js';
import { getCurrentPhase, getTimeUntilNextPhase, getTodayDateKey, getPhaseDeadline, getEasternTimeString } from './utils/timeUtils.js';
import { generateKeyLineOptions, generateKeyWordOptions, generateSkinnyPoem, generateImagePrompt } from './utils/poemGenerator.js';
import { VotingInterface, MoodVotingInterface } from './components/VotingInterface.js';
import { PoemDisplay, PoemArchive } from './components/PoemDisplay.js';
import { LoadingState, ErrorState, EmptyState, SuccessState } from './components/LoadingState.js';
import { SkinnyPoem, VotingSession, MoodVotingSession, MoodVariable, MoodSettings } from './types.js';
import { validateKeyLine, validateKeyWord, validateMoodValue, validateUserId, validateVotingOptionIndex } from './utils/validation.js';

// Configure the app
Devvit.configure({
  redditAPI: true,
  redis: true,
});

// Enhanced settings with configuration options
Devvit.addSettings([
  {
    name: 'openai_api_key',
    type: 'string',
    label: 'OpenAI API Key',
    helpText: 'Your OpenAI API key for generating image prompts. Get one from https://platform.openai.com/api-keys',
    isSecret: true,
  },
  {
    name: 'auto_post_enabled',
    type: 'boolean',
    label: 'Auto-post Daily Poems',
    helpText: 'Automatically create posts for completed daily poems',
    defaultValue: true,
  },
  {
    name: 'keyline_voting_duration',
    type: 'number',
    label: 'Key Line Voting Duration (hours)',
    helpText: 'How long key line voting lasts (default: 4 hours)',
    defaultValue: 4,
  },
  {
    name: 'keyword_voting_duration',
    type: 'number',
    label: 'Key Word Voting Duration (hours)',
    helpText: 'How long key word voting lasts (default: 4 hours)',
    defaultValue: 4,
  },
  {
    name: 'mood_voting_duration',
    type: 'number',
    label: 'Mood Voting Duration (hours)',
    helpText: 'How long mood voting lasts (default: 4 hours)',
    defaultValue: 4,
  },
  {
    name: 'max_votes_per_hour',
    type: 'number',
    label: 'Max Votes Per User Per Hour',
    helpText: 'Rate limit for voting (default: 10)',
    defaultValue: 10,
  },
]);

const MOOD_VARIABLES: MoodVariable[] = [
  { name: 'happiness', label: 'Happiness', min: 1, max: 10 },
  { name: 'energy', label: 'Energy', min: 1, max: 10 },
  { name: 'mystery', label: 'Mystery', min: 1, max: 10 },
  { name: 'romance', label: 'Romance', min: 1, max: 10 },
  { name: 'darkness', label: 'Darkness', min: 1, max: 10 },
  { name: 'nature', label: 'Nature', min: 1, max: 10 },
];

// Menu action to access the daily poem
Devvit.addMenuItem({
  label: 'Daily Skinny Poem',
  location: 'subreddit',
  onPress: async (event, context) => {
    try {
      const { reddit, ui } = context;
      const subreddit = await reddit.getSubredditById(event.context.subredditId!);
      const easternTime = getEasternTimeString();
      
      // Create a custom post
      const post = await reddit.submitPost({
        title: `Daily Skinny Poem - ${easternTime.split(',')[0]} ET`,
        subredditName: subreddit.name,
        preview: {
          title: 'Daily Skinny Poem',
          description: 'Collaborative poem creation through community voting (Eastern Time)',
        }
      });
      
      ui.showToast({ text: 'Daily Skinny Poem post created!', appearance: 'success' });
    } catch (error) {
      console.error('Error creating poem post:', error);
      context.ui.showToast({ text: 'Failed to create poem post', appearance: 'neutral' });
    }
  },
});

// Enhanced admin menu actions
Devvit.addMenuItem({
  label: '[Admin] Simulate Current Phase',
  location: 'subreddit',
  onPress: async (event, context) => {
    try {
      const { reddit, ui } = context;
      
      // Check if user is moderator
      const subreddit = await reddit.getSubredditById(event.context.subredditId!);
      const user = await reddit.getCurrentUser();
      
      if (!user) {
        ui.showToast({ text: 'Authentication required', appearance: 'neutral' });
        return;
      }
      
      const isModerator = await reddit.getModPermissions(subreddit.name, user.username);
      
      if (!isModerator || isModerator.length === 0) {
        ui.showToast({ text: 'Only moderators can use admin functions', appearance: 'neutral' });
        return;
      }

      const storage = new StorageManager(context);
      const { phase } = getCurrentPhase();
      const today = getTodayDateKey();

      if (phase === 'keyline') {
        await simulateKeyLinePhase(storage, today);
        ui.showToast({ text: 'Key line phase simulated - moved to keyword voting', appearance: 'success' });
      } else if (phase === 'keyword') {
        await simulateKeyWordPhase(storage, today);
        ui.showToast({ text: 'Key word phase simulated - moved to mood voting', appearance: 'success' });
      } else if (phase === 'mood') {
        await simulateMoodPhase(storage, today);
        ui.showToast({ text: 'Mood phase simulated - moved to generation', appearance: 'success' });
      } else if (phase === 'generation') {
        await simulateGenerationPhase(storage, today, context);
        ui.showToast({ text: 'Generation phase simulated - poem completed!', appearance: 'success' });
      } else {
        ui.showToast({ text: 'No active phase to simulate', appearance: 'neutral' });
      }
    } catch (error) {
      console.error('Admin simulation error:', error);
      context.ui.showToast({ text: 'Simulation failed', appearance: 'neutral' });
    }
  },
});

// Admin cleanup action
Devvit.addMenuItem({
  label: '[Admin] Cleanup Expired Data',
  location: 'subreddit',
  onPress: async (event, context) => {
    try {
      const { reddit, ui } = context;
      
      // Check if user is moderator
      const subreddit = await reddit.getSubredditById(event.context.subredditId!);
      const user = await reddit.getCurrentUser();
      
      if (!user) {
        ui.showToast({ text: 'Authentication required', appearance: 'neutral' });
        return;
      }
      
      const isModerator = await reddit.getModPermissions(subreddit.name, user.username);
      
      if (!isModerator || isModerator.length === 0) {
        ui.showToast({ text: 'Only moderators can use admin functions', appearance: 'neutral' });
        return;
      }

      const storage = new StorageManager(context);
      const result = await storage.cleanupExpiredData();
      
      ui.showToast({ 
        text: `Cleanup complete: ${result.cleaned} items cleaned, ${result.errors} errors`, 
        appearance: result.errors > 0 ? 'neutral' : 'success' 
      });
    } catch (error) {
      console.error('Admin cleanup error:', error);
      context.ui.showToast({ text: 'Cleanup failed', appearance: 'neutral' });
    }
  },
});

// Custom post type for the skinny poem app
Devvit.addCustomPostType({
  name: 'Skinny Poem Generator',
  height: 'tall',
  render: (context) => {
    const [currentView, setCurrentView] = useState<'main' | 'archive' | 'poem'>('main');
    const [selectedPoem, setSelectedPoem] = useState<SkinnyPoem | null>(null);
    const [refreshTrigger, setRefreshTrigger] = useState(0);
    const [error, setError] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [rateLimitInfo, setRateLimitInfo] = useState<any>(null);

    const storage = new StorageManager(context);
    const today = getTodayDateKey();
    const { phase, nextPhaseTime } = getCurrentPhase();

    // Auto-refresh every minute with error handling
    useInterval(() => {
      try {
        setRefreshTrigger(prev => prev + 1);
      } catch (error) {
        console.error('Error in auto-refresh:', error);
      }
    }, 60000);

    // Load rate limit info
    useAsync(async () => {
      try {
        const userId = context.userId || 'anonymous';
        const voteRateLimit = await storage.getRateLimitStatus(userId, 'vote');
        const moodRateLimit = await storage.getRateLimitStatus(userId, 'mood');
        
        setRateLimitInfo({
          vote: voteRateLimit,
          mood: moodRateLimit
        });
      } catch (err) {
        console.error('Error loading rate limit info:', err);
      }
    }, { depends: [refreshTrigger] });

    // Load today's poem and voting sessions with better error handling
    const { data: todaysPoem, loading: poemLoading, error: poemError } = useAsync(async () => {
      try {
        return await storage.getTodaysPoem(today);
      } catch (err) {
        console.error('Error loading today\'s poem:', err);
        throw new Error('Failed to load today\'s poem');
      }
    }, { depends: [refreshTrigger] });

    const { data: votingSession, loading: votingLoading, error: votingError } = useAsync(async () => {
      if (phase === 'keyline' || phase === 'keyword') {
        try {
          return await storage.getVotingSession(`${today}-${phase}`);
        } catch (err) {
          console.error('Error loading voting session:', err);
          return null;
        }
      }
      return null;
    }, { depends: [refreshTrigger, phase] });

    const { data: moodSession, loading: moodLoading, error: moodError } = useAsync(async () => {
      if (phase === 'mood') {
        try {
          return await storage.getMoodVotingSession(`${today}-mood`);
        } catch (err) {
          console.error('Error loading mood session:', err);
          return null;
        }
      }
      return null;
    }, { depends: [refreshTrigger, phase] });

    const { data: allPoems, loading: archiveLoading, error: archiveError } = useAsync(async () => {
      if (currentView === 'archive') {
        try {
          return await storage.getAllPoems(20, 0);
        } catch (err) {
          console.error('Error loading poems archive:', err);
          throw new Error('Failed to load poem archive');
        }
      }
      return [];
    }, { depends: [currentView] });

    // Initialize voting sessions if needed with better error handling
    useAsync(async () => {
      try {
        if (phase === 'keyline' && !votingSession && !todaysPoem) {
          await initializeKeyLineVoting(storage, today);
          setRefreshTrigger(prev => prev + 1);
        } else if (phase === 'keyword' && !votingSession && todaysPoem && !todaysPoem.keyWord) {
          await initializeKeyWordVoting(storage, today, todaysPoem.keyLine);
          setRefreshTrigger(prev => prev + 1);
        } else if (phase === 'mood' && !moodSession && todaysPoem && todaysPoem.keyWord && !todaysPoem.isComplete) {
          await initializeMoodVoting(storage, today);
          setRefreshTrigger(prev => prev + 1);
        } else if (phase === 'generation' && todaysPoem && todaysPoem.keyWord && !todaysPoem.isComplete) {
          await completePoem(storage, today, context);
          setRefreshTrigger(prev => prev + 1);
        }
      } catch (err) {
        console.error('Error initializing phase:', err);
        setError('Failed to initialize voting phase');
      }
    }, { depends: [phase, votingSession, moodSession, todaysPoem] });

    const handleVote = async (optionIndex: number) => {
      if (!votingSession) return;
      
      setIsLoading(true);
      setError(null);
      
      try {
        const userId = context.userId || 'anonymous';
        
        // Validate inputs
        const userValidation = validateUserId(userId);
        if (!userValidation.isValid) {
          throw new Error(userValidation.error);
        }
        
        const optionValidation = validateVotingOptionIndex(optionIndex, votingSession.options.length);
        if (!optionValidation.isValid) {
          throw new Error(optionValidation.error);
        }
        
        const result = await storage.recordVote(votingSession.id, userId, optionIndex);
        
        if (result.success) {
          setRefreshTrigger(prev => prev + 1);
          setRateLimitInfo(prev => ({ ...prev, vote: result.rateLimitInfo }));
          context.ui.showToast({ text: 'Vote recorded!', appearance: 'success' });
        } else {
          throw new Error(result.error || 'Voting failed');
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to record vote';
        setError(errorMessage);
        context.ui.showToast({ text: errorMessage, appearance: 'neutral' });
      } finally {
        setIsLoading(false);
      }
    };

    const handleMoodVote = async (variable: string, value: number) => {
      if (!moodSession) return;
      
      setIsLoading(true);
      setError(null);
      
      try {
        const userId = context.userId || 'anonymous';
        
        // Validate inputs
        const userValidation = validateUserId(userId);
        if (!userValidation.isValid) {
          throw new Error(userValidation.error);
        }
        
        const valueValidation = validateMoodValue(value);
        if (!valueValidation.isValid) {
          throw new Error(valueValidation.error);
        }
        
        const result = await storage.recordMoodVote(moodSession.id, userId, variable, value);
        
        if (result.success) {
          setRefreshTrigger(prev => prev + 1);
          setRateLimitInfo(prev => ({ ...prev, mood: result.rateLimitInfo }));
          context.ui.showToast({ text: 'Mood vote recorded!', appearance: 'success' });
        } else {
          throw new Error(result.error || 'Mood voting failed');
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to record mood vote';
        setError(errorMessage);
        context.ui.showToast({ text: errorMessage, appearance: 'neutral' });
      } finally {
        setIsLoading(false);
      }
    };

    const timeRemaining = getTimeUntilNextPhase();

    // Archive view
    if (currentView === 'archive') {
      return (
        <vstack gap="medium" padding="medium">
          <hstack gap="small" alignment="center middle">
            <button onPress={() => setCurrentView('main')} appearance="secondary" size="small">
              ← Back
            </button>
            <text size="large" weight="bold" grow>
              📚 Poem Archive
            </text>
          </hstack>
          
          <PoemArchive 
            poems={allPoems || []}
            onSelectPoem={(poem) => {
              setSelectedPoem(poem);
              setCurrentView('poem');
            }}
            isLoading={archiveLoading}
            error={archiveError?.message}
          />
        </vstack>
      );
    }

    // Individual poem view
    if (currentView === 'poem' && selectedPoem) {
      return (
        <vstack gap="medium" padding="medium">
          <hstack gap="small" alignment="center middle">
            <button onPress={() => setCurrentView('archive')} appearance="secondary" size="small">
              ← Back to Archive
            </button>
          </hstack>
          
          <PoemDisplay poem={selectedPoem} />
        </vstack>
      );
    }

    // Main view
    return (
      <vstack gap="medium" padding="medium">
        <hstack gap="small" alignment="center middle">
          <text size="xlarge" weight="bold" grow>
            🎭 Daily Skinny Poem
          </text>
          <button onPress={() => setCurrentView('archive')} appearance="secondary" size="small">
            Archive
          </button>
        </hstack>

        <vstack gap="small" padding="small" backgroundColor="neutral-background-weak">
          <hstack gap="small" alignment="center middle">
            <text size="medium" weight="bold" grow>
              Current Phase: {phase.charAt(0).toUpperCase() + phase.slice(1)}
            </text>
            <text size="small" color="neutral-content-weak">
              {timeRemaining}
            </text>
          </hstack>
          <text size="small" color="neutral-content-weak" alignment="center middle">
            All times are Eastern Time (ET)
          </text>
        </vstack>

        {/* Error display */}
        {error && (
          <ErrorState 
            error={error} 
            onRetry={() => {
              setError(null);
              setRefreshTrigger(prev => prev + 1);
            }}
            isTemporary={error.includes('network') || error.includes('timeout')}
          />
        )}

        {/* Voting interfaces */}
        {votingSession && (phase === 'keyline' || phase === 'keyword') && (
          <VotingInterface
            session={votingSession}
            userVote={votingSession.userVotes[context.userId || 'anonymous']}
            onVote={handleVote}
            timeRemaining={timeRemaining}
            isLoading={isLoading || votingLoading}
            error={votingError?.message}
            rateLimitInfo={rateLimitInfo?.vote}
          />
        )}

        {moodSession && phase === 'mood' && (
          <MoodVotingInterface
            session={moodSession}
            userVotes={moodSession.votes[context.userId || 'anonymous'] || {}}
            onVote={handleMoodVote}
            timeRemaining={timeRemaining}
            isLoading={isLoading || moodLoading}
            error={moodError?.message}
            rateLimitInfo={rateLimitInfo?.mood}
          />
        )}

        {/* Generation phase */}
        {phase === 'generation' && todaysPoem && !todaysPoem.isComplete && (
          <LoadingState 
            message="Generating today's poem based on your votes..." 
            showProgress={true}
            progressSteps={[
              'Processing voting results',
              'Calculating mood averages',
              'Generating poem structure',
              'Creating final poem',
              'Generating image prompt'
            ]}
            currentStep={2}
          />
        )}

        {/* Completed poem */}
        {todaysPoem && todaysPoem.isComplete && (
          <SuccessState
            title="Today's Poem Complete!"
            description="The collaborative poem has been generated based on community votes."
          />
        )}

        {todaysPoem && todaysPoem.isComplete && (
          <PoemDisplay poem={todaysPoem} />
        )}

        {/* Waiting for next day */}
        {phase === 'complete' && (
          <vstack gap="medium" padding="medium" backgroundColor="neutral-background-weak">
            <text size="large" weight="bold">
              🌙 Today's Poem Complete
            </text>
            <text wrap>
              Today's collaborative poem has been completed! 
              Voting for tomorrow's poem will begin at 8 AM ET.
            </text>
            {todaysPoem && todaysPoem.isComplete && (
              <PoemDisplay poem={todaysPoem} compact />
            )}
          </vstack>
        )}

        {/* Phase descriptions */}
        <vstack gap="small" padding="medium" backgroundColor="neutral-background-weak">
          <text size="small" weight="bold">📅 Daily Schedule (Eastern Time):</text>
          <text size="small">8AM-12PM ET: Vote for Key Line</text>
          <text size="small">12PM-4PM ET: Vote for Key Word</text>
          <text size="small">4PM-8PM ET: Set Poem Mood</text>
          <text size="small">8PM-9PM ET: Poem Generation</text>
          <text size="small">9PM ET: Daily Poem Published</text>
        </vstack>
      </vstack>
    );
  },
});

// Helper functions for phase management with enhanced error handling
async function initializeKeyLineVoting(storage: StorageManager, date: string): Promise<void> {
  try {
    const options = generateKeyLineOptions();
    const session: VotingSession = {
      id: `${date}-keyline`,
      phase: 'keyline',
      options,
      votes: {},
      userVotes: {},
      deadline: getPhaseDeadline('keyline'),
      isActive: true,
      poemId: date,
    };
    
    await storage.saveVotingSession(session);
    console.log(`Initialized key line voting for ${date}`);
  } catch (error) {
    console.error('Error initializing key line voting:', error);
    throw error;
  }
}

async function initializeKeyWordVoting(storage: StorageManager, date: string, keyLine: string): Promise<void> {
  try {
    const validation = validateKeyLine(keyLine);
    if (!validation.isValid) {
      throw new Error(validation.error);
    }
    
    const options = generateKeyWordOptions(keyLine);
    const session: VotingSession = {
      id: `${date}-keyword`,
      phase: 'keyword',
      options,
      votes: {},
      userVotes: {},
      deadline: getPhaseDeadline('keyword'),
      isActive: true,
      poemId: date,
    };
    
    await storage.saveVotingSession(session);
    console.log(`Initialized key word voting for ${date}`);
  } catch (error) {
    console.error('Error initializing key word voting:', error);
    throw error;
  }
}

async function initializeMoodVoting(storage: StorageManager, date: string): Promise<void> {
  try {
    const session: MoodVotingSession = {
      id: `${date}-mood`,
      variables: MOOD_VARIABLES,
      votes: {},
      deadline: getPhaseDeadline('mood'),
      isActive: true,
      poemId: date,
    };
    
    await storage.saveMoodVotingSession(session);
    console.log(`Initialized mood voting for ${date}`);
  } catch (error) {
    console.error('Error initializing mood voting:', error);
    throw error;
  }
}

async function completePoem(storage: StorageManager, date: string, context: any): Promise<void> {
  try {
    const poem = await storage.getTodaysPoem(date);
    if (!poem || poem.isComplete) return;

    const moodResult = await storage.getMoodVotingResult(`${date}-mood`);
    const lines = generateSkinnyPoem(poem.keyLine, poem.keyWord, moodResult);
    const imagePrompt = generateImagePrompt(lines, moodResult);

    const completedPoem: SkinnyPoem = {
      ...poem,
      mood: moodResult,
      lines,
      imagePrompt,
      isComplete: true,
    };

    await storage.saveTodaysPoem(completedPoem);
    console.log(`Completed poem for ${date}`);

    // Auto-post if enabled with better error handling
    try {
      const settings = await context.settings.getAll();
      if (settings.auto_post_enabled) {
        const subreddit = await context.reddit.getSubredditById(context.subredditId);
        const poemText = lines.join('\n');
        const easternTime = getEasternTimeString();
        
        await context.reddit.submitPost({
          title: `Daily Skinny Poem - ${easternTime.split(',')[0]} ET`,
          text: `${poemText}\n\n---\n\n*This poem was created collaboratively by the community through daily voting phases. All times are Eastern Time.*`,
          subredditName: subreddit.name,
        });
        
        console.log(`Auto-posted poem for ${date}`);
      }
    } catch (postError) {
      console.error('Failed to auto-post poem:', postError);
      // Don't throw - poem completion is more important than posting
    }
  } catch (error) {
    console.error('Error completing poem:', error);
    throw error;
  }
}

// Admin simulation functions with enhanced error handling
async function simulateKeyLinePhase(storage: StorageManager, date: string): Promise<void> {
  try {
    const session = await storage.getVotingSession(`${date}-keyline`);
    if (!session) return;

    const winner = await storage.getVotingWinner(session.id);
    if (!winner) return;

    const poem: SkinnyPoem = {
      id: date,
      date,
      keyLine: winner.option,
      keyWord: '',
      mood: { happiness: 5, energy: 5, mystery: 5, romance: 5, darkness: 5, nature: 5 },
      lines: [],
      imagePrompt: '',
      isComplete: false,
      createdAt: Date.now(),
    };

    await storage.saveTodaysPoem(poem);
    session.isActive = false;
    await storage.saveVotingSession(session);
    console.log(`Simulated key line phase for ${date}`);
  } catch (error) {
    console.error('Error simulating key line phase:', error);
    throw error;
  }
}

async function simulateKeyWordPhase(storage: StorageManager, date: string): Promise<void> {
  try {
    const session = await storage.getVotingSession(`${date}-keyword`);
    if (!session) return;

    const winner = await storage.getVotingWinner(session.id);
    if (!winner) return;

    const poem = await storage.getTodaysPoem(date);
    if (!poem) return;

    poem.keyWord = winner.option;
    await storage.saveTodaysPoem(poem);
    
    session.isActive = false;
    await storage.saveVotingSession(session);
    console.log(`Simulated key word phase for ${date}`);
  } catch (error) {
    console.error('Error simulating key word phase:', error);
    throw error;
  }
}

async function simulateMoodPhase(storage: StorageManager, date: string): Promise<void> {
  try {
    const session = await storage.getMoodVotingSession(`${date}-mood`);
    if (!session) return;

    session.isActive = false;
    await storage.saveMoodVotingSession(session);
    console.log(`Simulated mood phase for ${date}`);
  } catch (error) {
    console.error('Error simulating mood phase:', error);
    throw error;
  }
}

async function simulateGenerationPhase(storage: StorageManager, date: string, context: any): Promise<void> {
  try {
    await completePoem(storage, date, context);
    console.log(`Simulated generation phase for ${date}`);
  } catch (error) {
    console.error('Error simulating generation phase:', error);
    throw error;
  }
}

export default Devvit;