/**
 * Constants for the Vibepoem application
 */

// Time constants
export const HOURS_IN_MS = 60 * 60 * 1000;
export const MINUTES_IN_MS = 60 * 1000;
export const SECONDS_IN_MS = 1000;

// Phase durations (in hours)
export const DEFAULT_KEYLINE_VOTING_DURATION = 4;
export const DEFAULT_KEYWORD_VOTING_DURATION = 4;
export const DEFAULT_MOOD_VOTING_DURATION = 4;

// Phase start times (Eastern Time)
export const KEYLINE_PHASE_START_HOUR = 8; // 8 AM ET
export const KEYWORD_PHASE_START_HOUR = 12; // 12 PM ET
export const MOOD_PHASE_START_HOUR = 16; // 4 PM ET
export const GENERATION_PHASE_START_HOUR = 20; // 8 PM ET
export const COMPLETE_PHASE_START_HOUR = 21; // 9 PM ET

// Rate limiting
export const DEFAULT_MAX_VOTES_PER_HOUR = 10;
export const DEFAULT_MAX_MOOD_VOTES_PER_HOUR = 50;

// Storage keys
export const STORAGE_KEY_PREFIX = 'vibepoem';
export const POEM_KEY_PREFIX = 'poem';
export const VOTING_KEY_PREFIX = 'voting';
export const MOOD_VOTING_KEY_PREFIX = 'mood_voting';
export const RATE_LIMIT_KEY_PREFIX = 'rate_limit';
export const ADMIN_KEY_PREFIX = 'admin';

// Redis TTL values (in milliseconds)
export const POEM_TTL_MS = 365 * 24 * 60 * 60 * 1000; // 1 year
export const VOTING_SESSION_TTL_BUFFER_MS = 30 * 60 * 1000; // 30 minutes
export const RATE_LIMIT_TTL_MS = 60 * 60 * 1000; // 1 hour

// Cache TTL values (in milliseconds)
export const CACHE_TTL_SHORT_MS = 30 * 1000; // 30 seconds
export const CACHE_TTL_MEDIUM_MS = 60 * 1000; // 1 minute
export const CACHE_TTL_LONG_MS = 5 * 60 * 1000; // 5 minutes