/**
 * Shared utility functions for the Vibepoem application
 */

/**
 * Formats a date as a string in Eastern Time
 * @param date The date to format
 * @returns Formatted date string in Eastern Time
 */
export function formatEasternTime(date: Date): string {
  try {
    return date.toLocaleString("en-US", {
      timeZone: "America/New_York",
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  } catch (error) {
    console.error('Error formatting Eastern time:', error);
    return date.toLocaleString();
  }
}

/**
 * Generates a random integer between min and max (inclusive)
 * @param min Minimum value
 * @param max Maximum value
 * @returns Random integer
 */
export function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Shuffles an array in place using Fisher-Yates algorithm
 * @param array The array to shuffle
 */
export function shuffleArray<T>(array: T[]): void {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

/**
 * Creates a deterministic hash from a string
 * @param str The string to hash
 * @returns A number between 0 and 1
 */
export function deterministicHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0; // Convert to 32bit integer
  }
  return (hash % 1000) / 1000;
}