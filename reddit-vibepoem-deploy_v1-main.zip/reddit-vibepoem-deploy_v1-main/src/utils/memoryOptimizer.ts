// Memory optimization utilities
export class MemoryOptimizer {
  private static cleanupInterval: NodeJS.Timeout | null = null;
  private static cache = new Map<string, { data: any; timestamp: number }>();
  
  static startCleanup(): void {
    // Clean up cache every 5 minutes
    this.cleanupInterval = setInterval(() => {
      this.cleanExpiredCache();
    }, 5 * 60 * 1000);
  }
  
  static stopCleanup(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }
  
  static cleanExpiredCache(): void {
    const now = Date.now();
    const expiredKeys: string[] = [];
    
    for (const [key, value] of this.cache.entries()) {
      if (now - value.timestamp > 300000) { // 5 minutes
        expiredKeys.push(key);
      }
    }
    
    expiredKeys.forEach(key => this.cache.delete(key));
    
    if (expiredKeys.length > 0) {
      console.log(`🧹 Cleaned ${expiredKeys.length} expired cache entries`);
    }
  }
  
  static clearAllCache(): void {
    this.cache.clear();
    console.log('🧹 All cache cleared');
  }
  
  static getMemoryUsage(): { used: number; total: number } {
    if (typeof performance !== 'undefined' && performance.memory) {
      return {
        used: Math.round(performance.memory.usedJSHeapSize / 1024 / 1024),
        total: Math.round(performance.memory.totalJSHeapSize / 1024 / 1024)
      };
    }
    return { used: 0, total: 0 };
  }
}

// Auto-start cleanup
MemoryOptimizer.startCleanup();