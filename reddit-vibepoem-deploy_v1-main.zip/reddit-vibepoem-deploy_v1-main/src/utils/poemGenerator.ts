import { MoodSettings, WordOption, PoemLine } from '../types.js';
import { getRandomInt, shuffleArray } from '../shared/utils.js';

const PUNCTUATION_OPTIONS = [',', '-', ':', ';'];
const WORD_POOLS = {
  verbs: ['dance', 'whisper', 'bloom', 'shatter', 'embrace', 'wander', 'gleam', 'flutter', 'cascade', 'shimmer'],
  prepositions: ['through', 'beneath', 'beyond', 'within', 'across', 'among', 'beside', 'above', 'below', 'around'],
  nouns: ['shadow', 'light', 'dream', 'echo', 'flame', 'mist', 'star', 'wave', 'wind', 'heart'],
  adjectives: ['gentle', 'fierce', 'silent', 'radiant', 'ancient', 'tender', 'wild', 'serene', 'vibrant', 'ethereal'],
  adverbs: ['softly', 'boldly', 'quietly', 'swiftly', 'deeply', 'gently', 'fiercely', 'slowly', 'gracefully', 'mysteriously']
};

export function generateKeyLineOptions(): string[] {
  const templates = [
    "In the {adjective} {noun} of {noun}",
    "Where {noun} meets {noun} in {adjective} {noun}",
    "Through {adjective} {noun} and {adjective} {noun}",
    "Beyond the {noun} lies {adjective} {noun}",
    "Within {adjective} {noun}, {noun} {verbs}"
  ];
  
  return templates.map(template => {
    let line = template;
    line = line.replace(/{adjective}/g, () => getRandomWord('adjectives'));
    line = line.replace(/{noun}/g, () => getRandomWord('nouns'));
    line = line.replace(/{verbs}/g, () => getRandomWord('verbs'));
    
    const punct = PUNCTUATION_OPTIONS[getRandomInt(0, PUNCTUATION_OPTIONS.length - 1)];
    return line + punct;
  });
}

export function generateKeyWordOptions(keyLine: string): string[] {
  // Extract meaningful words from key line for context
  const words = keyLine.toLowerCase().split(' ').filter(w => w.length > 3);
  const contextWords = [...WORD_POOLS.nouns, ...WORD_POOLS.adjectives, ...WORD_POOLS.verbs];
  
  // Generate 5 contextually relevant key words
  const options = new Set<string>();
  while (options.size < 5) {
    const word = contextWords[getRandomInt(0, contextWords.length - 1)];
    if (!keyLine.toLowerCase().includes(word)) {
      options.add(word);
    }
  }
  
  return Array.from(options);
}

export function generateSkinnyPoem(keyLine: string, keyWord: string, mood: MoodSettings): string[] {
  const lines: string[] = new Array(11);
  
  // Lines 1 and 11 (Key Line)
  lines[0] = keyLine;
  lines[10] = keyLine.replace(/[,:;-]$/, '.'); // Replace punctuation with period
  
  // Lines 2, 6, 9 (Key Word)
  const keyWordPunct = PUNCTUATION_OPTIONS[getRandomInt(0, PUNCTUATION_OPTIONS.length - 1)];
  lines[1] = keyWord + keyWordPunct;
  lines[5] = keyWord + keyWordPunct;
  lines[8] = keyWord + keyWordPunct;
  
  // Generate words for lines 3-5, 7-8, 10 based on mood
  const moodAdjustedWords = adjustWordsForMood(mood);
  const usedWords = new Set([keyWord]);
  
  // Lines 3-5: verb, preposition, noun/adjective/adverb (one each)
  const line3to5Types = ['verb', 'preposition', 'noun'];
  shuffleArray(line3to5Types);
  
  for (let i = 0; i < 3; i++) {
    const type = line3to5Types[i] as keyof typeof moodAdjustedWords;
    const word = getUniqueWord(moodAdjustedWords[type], usedWords);
    const punct = (i === 1) ? '' : PUNCTUATION_OPTIONS[getRandomInt(0, PUNCTUATION_OPTIONS.length - 1)];
    lines[2 + i] = word + punct;
  }
  
  // Lines 7-8: preposition, adjective/verb
  const line7Type = 'preposition';
  const line8Type = Math.random() > 0.5 ? 'adjective' : 'verb';
  
  const word7 = getUniqueWord(moodAdjustedWords[line7Type], usedWords);
  const word8 = getUniqueWord(moodAdjustedWords[line8Type], usedWords);
  
  lines[6] = word7;
  lines[7] = word8 + PUNCTUATION_OPTIONS[getRandomInt(0, PUNCTUATION_OPTIONS.length - 1)];
  
  // Line 10: adjective/noun
  const line10Type = Math.random() > 0.5 ? 'adjective' : 'noun';
  const word10 = getUniqueWord(moodAdjustedWords[line10Type], usedWords);
  lines[9] = word10;
  
  return lines;
}

function adjustWordsForMood(mood: MoodSettings): Record<string, string[]> {
  const adjusted = { ...WORD_POOLS };
  
  // Adjust word pools based on mood settings
  if (mood.happiness > 6) {
    adjusted.adjectives = [...adjusted.adjectives, 'joyful', 'bright', 'cheerful', 'radiant'];
    adjusted.verbs = [...adjusted.verbs, 'laugh', 'sing', 'celebrate', 'rejoice'];
  }
  
  if (mood.darkness > 6) {
    adjusted.adjectives = [...adjusted.adjectives, 'dark', 'shadowy', 'mysterious', 'haunting'];
    adjusted.nouns = [...adjusted.nouns, 'shadow', 'void', 'abyss', 'darkness'];
  }
  
  if (mood.nature > 6) {
    adjusted.nouns = [...adjusted.nouns, 'forest', 'ocean', 'mountain', 'river', 'sky'];
    adjusted.adjectives = [...adjusted.adjectives, 'wild', 'natural', 'organic', 'earthy'];
  }
  
  if (mood.romance > 6) {
    adjusted.adjectives = [...adjusted.adjectives, 'tender', 'passionate', 'loving', 'intimate'];
    adjusted.nouns = [...adjusted.nouns, 'heart', 'soul', 'kiss', 'embrace'];
  }
  
  return adjusted;
}

function getRandomWord(category: keyof typeof WORD_POOLS): string {
  const words = WORD_POOLS[category];
  return words[getRandomInt(0, words.length - 1)];
}

function getUniqueWord(words: string[], usedWords: Set<string>): string {
  const available = words.filter(w => !usedWords.has(w));
  if (available.length === 0) {
    // Fallback if all words used
    return words[getRandomInt(0, words.length - 1)];
  }
  const word = available[getRandomInt(0, available.length - 1)];
  usedWords.add(word);
  return word;
}

export function generateImagePrompt(poem: string[], mood: MoodSettings): string {
  const keyLine = poem[0];
  const keyWord = poem[1].replace(/[,:;-]$/, '');
  
  let style = "artistic, poetic, dreamy";
  
  if (mood.happiness > 6) style += ", bright, joyful, warm colors";
  if (mood.darkness > 6) style += ", dark, mysterious, deep shadows";
  if (mood.nature > 6) style += ", natural, organic, landscape";
  if (mood.romance > 6) style += ", romantic, soft, intimate";
  if (mood.energy > 6) style += ", dynamic, vibrant, energetic";
  if (mood.mystery > 6) style += ", enigmatic, surreal, atmospheric";
  
  return `${keyLine} ${keyWord}, ${style}, digital art, high quality`;
}