import { 
  HOURS_IN_MS, 
  MINUTES_IN_MS, 
  KEYLINE_PHASE_START_HOUR, 
  KEYWORD_PHASE_START_HOUR, 
  MOOD_PHASE_START_HOUR, 
  GENERATION_PHASE_START_HOUR, 
  COMPLETE_PHASE_START_HOUR 
} from '../shared/constants.js';

export function getCurrentPhase(): { phase: string; nextPhaseTime: number } {
  const now = getEasternTime();
  const hour = now.getHours();
  
  if (hour >= KEYLINE_PHASE_START_HOUR && hour < KEYWORD_PHASE_START_HOUR) {
    const nextPhase = getEasternTimeAtHour(KEYWORD_PHASE_START_HOUR);
    return { phase: 'keyline', nextPhaseTime: nextPhase.getTime() };
  } else if (hour >= KEYWORD_PHASE_START_HOUR && hour < MOOD_PHASE_START_HOUR) {
    const nextPhase = getEasternTimeAtHour(MOOD_PHASE_START_HOUR);
    return { phase: 'keyword', nextPhaseTime: nextPhase.getTime() };
  } else if (hour >= MOOD_PHASE_START_HOUR && hour < GENERATION_PHASE_START_HOUR) {
    const nextPhase = getEasternTimeAtHour(GENERATION_PHASE_START_HOUR);
    return { phase: 'mood', nextPhaseTime: nextPhase.getTime() };
  } else if (hour >= GENERATION_PHASE_START_HOUR && hour < COMPLETE_PHASE_START_HOUR) {
    const nextPhase = getEasternTimeAtHour(COMPLETE_PHASE_START_HOUR);
    return { phase: 'generation', nextPhaseTime: nextPhase.getTime() };
  } else {
    // After 9PM or before 8AM - waiting for next day
    let nextPhase: Date;
    if (hour >= COMPLETE_PHASE_START_HOUR) {
      // Tomorrow at 8 AM ET
      nextPhase = getEasternTimeAtHour(KEYLINE_PHASE_START_HOUR, 1);
    } else {
      // Today at 8 AM ET
      nextPhase = getEasternTimeAtHour(KEYLINE_PHASE_START_HOUR);
    }
    return { phase: 'complete', nextPhaseTime: nextPhase.getTime() };
  }
}

export function getTimeUntilNextPhase(): string {
  const { nextPhaseTime } = getCurrentPhase();
  const now = getEasternTime().getTime();
  const diff = nextPhaseTime - now;
  
  if (diff <= 0) return "Phase transition in progress...";
  
  const hours = Math.floor(diff / HOURS_IN_MS);
  const minutes = Math.floor((diff % HOURS_IN_MS) / MINUTES_IN_MS);
  
  if (hours > 0) {
    return `${hours}h ${minutes}m remaining`;
  }
  return `${minutes}m remaining`;
}

export function getTodayDateKey(): string {
  const today = getEasternTime();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
}

export function getPhaseDeadline(phase: string): number {
  try {
    switch (phase) {
      case 'keyline':
        return getEasternTimeAtHour(KEYWORD_PHASE_START_HOUR).getTime();
      case 'keyword':
        return getEasternTimeAtHour(MOOD_PHASE_START_HOUR).getTime();
      case 'mood':
        return getEasternTimeAtHour(GENERATION_PHASE_START_HOUR).getTime();
      case 'generation':
        return getEasternTimeAtHour(COMPLETE_PHASE_START_HOUR).getTime();
      default:
        return getEasternTimeAtHour(KEYLINE_PHASE_START_HOUR, 1).getTime(); // Next day 8 AM ET
    }
  } catch (error) {
    console.error('Error calculating phase deadline:', error);
    // Fallback: 1 hour from now
    return Date.now() + HOURS_IN_MS;
  }
}

export function isPhaseActive(phase: string): boolean {
  const { phase: currentPhase } = getCurrentPhase();
  return currentPhase === phase;
}

export function getNextPhaseStartTime(): number {
  const { nextPhaseTime } = getCurrentPhase();
  return nextPhaseTime;
}

export function getEasternTime(): Date {
  try {
    // Create a new date in Eastern timezone
    const now = new Date();
    
    // Use Intl.DateTimeFormat to get Eastern time components
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
    
    const parts = formatter.formatToParts(now);
    const partsObj = parts.reduce((acc, part) => {
      acc[part.type] = part.value;
      return acc;
    }, {} as Record<string, string>);
    
    // Create date in Eastern timezone
    const easternTime = new Date(
      parseInt(partsObj.year),
      parseInt(partsObj.month) - 1, // Month is 0-indexed
      parseInt(partsObj.day),
      parseInt(partsObj.hour),
      parseInt(partsObj.minute),
      parseInt(partsObj.second)
    );
    
    return easternTime;
  } catch (error) {
    console.error('Error getting Eastern time:', error);
    // Fallback to UTC
    return new Date();
  }
}

export function getEasternTimeAtHour(hour: number, daysOffset: number = 0): Date {
  try {
    const easternNow = getEasternTime();
    const targetDate = new Date(easternNow);
    
    if (daysOffset !== 0) {
      targetDate.setDate(targetDate.getDate() + daysOffset);
    }
    
    targetDate.setHours(hour, 0, 0, 0);
    return targetDate;
  } catch (error) {
    console.error('Error getting Eastern time at hour:', error);
    // Fallback
    const fallback = new Date();
    fallback.setHours(hour, 0, 0, 0);
    return fallback;
  }
}

export function getEasternTimeString(): string {
  try {
    return formatEasternTime(getEasternTime());
  } catch (error) {
    console.error('Error getting Eastern time string:', error);
    return new Date().toLocaleString();
  }
}

export function convertToEasternTimestamp(utcTimestamp: number): number {
  try {
    const utcDate = new Date(utcTimestamp);
    const easternDate = new Date(utcDate.toLocaleString("en-US", {timeZone: "America/New_York"}));
    return easternDate.getTime();
  } catch (error) {
    console.error('Error converting to Eastern timestamp:', error);
    return utcTimestamp;
  }
}