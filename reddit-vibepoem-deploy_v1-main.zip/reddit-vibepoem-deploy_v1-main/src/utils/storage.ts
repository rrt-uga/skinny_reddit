import { Context } from '@devvit/public-api';
import { SkinnyPoem, VotingSession, MoodVotingSession, MoodSettings } from '../types.js';
import { convertToEasternTimestamp } from './timeUtils.js';
import { 
  STORAGE_KEY_PREFIX, 
  POEM_KEY_PREFIX, 
  VOTING_KEY_PREFIX, 
  MOOD_VOTING_KEY_PREFIX, 
  RATE_LIMIT_KEY_PREFIX,
  ADMIN_KEY_PREFIX,
  POEM_TTL_MS,
  VOTING_SESSION_TTL_BUFFER_MS,
  RATE_LIMIT_TTL_MS,
  DEFAULT_MAX_VOTES_PER_HOUR,
  DEFAULT_MAX_MOOD_VOTES_PER_HOUR,
  CACHE_TTL_SHORT_MS,
  CACHE_TTL_MEDIUM_MS,
  CACHE_TTL_LONG_MS
} from '../shared/constants.js';
import { deterministicHash } from '../shared/utils.js';

// Cache for expensive operations
const operationCache = new Map<string, { data: any; timestamp: number; ttl: number }>();

export class StorageManager {
  private context: Context;
  private subredditId: string;
  private retryAttempts: number = 3;
  private retryDelay: number = 1000; // 1 second base delay

  constructor(context: Context) {
    this.context = context;
    this.subredditId = context.subredditId || 'default';
  }

  private getKey(key: string): string {
    return `${this.subredditId}:${STORAGE_KEY_PREFIX}:${key}`;
  }

  // Enhanced caching mechanism
  private getCachedData<T>(key: string): T | null {
    const cached = operationCache.get(key);
    if (cached && Date.now() - cached.timestamp < cached.ttl) {
      return cached.data as T;
    }
    operationCache.delete(key);
    return null;
  }

  private setCachedData<T>(key: string, data: T, ttlMs: number = CACHE_TTL_MEDIUM_MS): void {
    operationCache.set(key, {
      data,
      timestamp: Date.now(),
      ttl: ttlMs
    });
  }

  // Network retry mechanism with exponential backoff
  private async retryOperation<T>(
    operation: () => Promise<T>,
    operationName: string,
    maxRetries: number = this.retryAttempts
  ): Promise<T> {
    let lastError: Error;
    
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        if (attempt === maxRetries) {
          console.error(`${operationName} failed after ${maxRetries + 1} attempts:`, error);
          throw error;
        }
        
        const delay = this.retryDelay * Math.pow(2, attempt);
        console.warn(`${operationName} attempt ${attempt + 1} failed, retrying in ${delay}ms:`, error);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
    
    throw lastError!;
  }

  // Rate limiting with user feedback
  async getRateLimitStatus(userId: string, type: 'vote' | 'mood'): Promise<{
    remaining: number;
    total: number;
    resetTime: number;
    isNearLimit: boolean;
  }> {
    try {
      const rateLimitKey = this.getKey(`${RATE_LIMIT_KEY_PREFIX}:${type}:${userId}`);
      const recentVotes = await this.context.redis.get(rateLimitKey);
      const voteCount = recentVotes ? parseInt(recentVotes) : 0;
      
      const maxVotes = type === 'vote' ? DEFAULT_MAX_VOTES_PER_HOUR : DEFAULT_MAX_MOOD_VOTES_PER_HOUR;
      const remaining = Math.max(0, maxVotes - voteCount);
      const resetTime = Date.now() + RATE_LIMIT_TTL_MS; // 1 hour from now
      const isNearLimit = remaining <= (maxVotes * 0.2); // Within 20% of limit
      
      return {
        remaining,
        total: maxVotes,
        resetTime,
        isNearLimit
      };
    } catch (error) {
      console.error('Error getting rate limit status:', error);
      return {
        remaining: 10,
        total: 10,
        resetTime: Date.now() + RATE_LIMIT_TTL_MS,
        isNearLimit: false
      };
    }
  }

  // Enhanced poem storage with TTL buffer
  async saveTodaysPoem(poem: SkinnyPoem): Promise<void> {
    return this.retryOperation(async () => {
      const key = this.getKey(`${POEM_KEY_PREFIX}:${poem.date}`);
      
      // Ensure timestamps are in Eastern Time
      const poemWithEasternTime = {
        ...poem,
        createdAt: convertToEasternTimestamp(poem.createdAt)
      };
      
      // Add 7 days buffer to TTL to prevent premature expiration
      const ttlMs = POEM_TTL_MS + (7 * 24 * 60 * 60 * 1000);
      
      await this.context.redis.set(
        key, 
        JSON.stringify(poemWithEasternTime), 
        { expiration: new Date(Date.now() + ttlMs) }
      );
      
      // Update cache
      this.setCachedData(`poem:${poem.date}`, poemWithEasternTime, CACHE_TTL_MEDIUM_MS);
    }, 'saveTodaysPoem');
  }

  async getTodaysPoem(date: string): Promise<SkinnyPoem | null> {
    // Check cache first
    const cacheKey = `poem:${date}`;
    const cached = this.getCachedData<SkinnyPoem>(cacheKey);
    if (cached) return cached;

    return this.retryOperation(async () => {
      const key = this.getKey(`${POEM_KEY_PREFIX}:${date}`);
      const data = await this.context.redis.get(key);
      const poem = data ? JSON.parse(data) : null;
      
      if (poem) {
        this.setCachedData(cacheKey, poem, CACHE_TTL_MEDIUM_MS); // Cache for 1 minute
      }
      
      return poem;
    }, 'getTodaysPoem');
  }

  async getAllPoems(limit: number = 20, offset: number = 0): Promise<SkinnyPoem[]> {
    const cacheKey = `all_poems:${limit}:${offset}`;
    const cached = this.getCachedData<SkinnyPoem[]>(cacheKey);
    if (cached) return cached;

    return this.retryOperation(async () => {
      const pattern = this.getKey(`${POEM_KEY_PREFIX}:*`);
      const keys = await this.context.redis.keys(pattern);
      const poems: SkinnyPoem[] = [];
      
      // Sort keys by date (newest first)
      const sortedKeys = keys.sort((a, b) => {
        const dateA = a.split(':').pop() || '';
        const dateB = b.split(':').pop() || '';
        return dateB.localeCompare(dateA);
      });
      
      // Apply pagination
      const paginatedKeys = sortedKeys.slice(offset, offset + limit);
      
      for (const key of paginatedKeys) {
        try {
          const data = await this.context.redis.get(key);
          if (data) {
            poems.push(JSON.parse(data));
          }
        } catch (error) {
          console.error(`Error parsing poem data for key ${key}:`, error);
        }
      }
      
      const sortedPoems = poems.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      this.setCachedData(cacheKey, sortedPoems, CACHE_TTL_LONG_MS); // Cache for 2 minutes
      
      return sortedPoems;
    }, 'getAllPoems');
  }

  // Enhanced voting session storage with TTL buffer
  async saveVotingSession(session: VotingSession): Promise<void> {
    return this.retryOperation(async () => {
      const key = this.getKey(`${VOTING_KEY_PREFIX}:${session.id}`);
      
      // Add 30 minute buffer to prevent premature expiration
      const bufferMs = VOTING_SESSION_TTL_BUFFER_MS;
      const ttl = Math.max(session.deadline - Date.now() + bufferMs, 60000);
      
      if (session.deadline < Date.now()) {
        console.warn(`Voting session ${session.id} deadline has passed, marking as inactive`);
        session.isActive = false;
      }
      
      await this.context.redis.set(key, JSON.stringify(session), { 
        expiration: new Date(Date.now() + ttl) 
      });
      
      // Clear cache
      operationCache.delete(`voting:${session.id}`);
    }, 'saveVotingSession');
  }

  async getVotingSession(id: string): Promise<VotingSession | null> {
    const cacheKey = `voting:${id}`;
    const cached = this.getCachedData<VotingSession>(cacheKey);
    if (cached) return cached;

    return this.retryOperation(async () => {
      const key = this.getKey(`${VOTING_KEY_PREFIX}:${id}`);
      const data = await this.context.redis.get(key);
      
      if (!data) return null;
      
      const session = JSON.parse(data);
      
      // Check if session has expired
      if (Date.now() > session.deadline) {
        session.isActive = false;
      }
      
      this.setCachedData(cacheKey, session, CACHE_TTL_SHORT_MS); // Cache for 30 seconds
      return session;
    }, 'getVotingSession');
  }

  async saveMoodVotingSession(session: MoodVotingSession): Promise<void> {
    return this.retryOperation(async () => {
      const key = this.getKey(`${MOOD_VOTING_KEY_PREFIX}:${session.id}`);
      
      // Add 30 minute buffer to prevent premature expiration
      const bufferMs = VOTING_SESSION_TTL_BUFFER_MS;
      const ttl = Math.max(session.deadline - Date.now() + bufferMs, 60000);
      
      if (session.deadline < Date.now()) {
        console.warn(`Mood voting session ${session.id} deadline has passed, marking as inactive`);
        session.isActive = false;
      }
      
      await this.context.redis.set(key, JSON.stringify(session), { 
        expiration: new Date(Date.now() + ttl) 
      });
      
      // Clear cache
      operationCache.delete(`mood_voting:${session.id}`);
    }, 'saveMoodVotingSession');
  }

  async getMoodVotingSession(id: string): Promise<MoodVotingSession | null> {
    const cacheKey = `mood_voting:${id}`;
    const cached = this.getCachedData<MoodVotingSession>(cacheKey);
    if (cached) return cached;

    return this.retryOperation(async () => {
      const key = this.getKey(`${MOOD_VOTING_KEY_PREFIX}:${id}`);
      const data = await this.context.redis.get(key);
      
      if (!data) return null;
      
      const session = JSON.parse(data);
      
      // Check if session has expired
      if (Date.now() > session.deadline) {
        session.isActive = false;
      }
      
      this.setCachedData(cacheKey, session, CACHE_TTL_SHORT_MS); // Cache for 30 seconds
      return session;
    }, 'getMoodVotingSession');
  }

  // Enhanced vote recording with better rate limiting feedback
  async recordVote(sessionId: string, userId: string, optionIndex: number): Promise<{
    success: boolean;
    error?: string;
    rateLimitInfo?: any;
  }> {
    return this.retryOperation(async () => {
      // Get rate limit status first
      const rateLimitInfo = await this.getRateLimitStatus(userId, 'vote');
      
      if (rateLimitInfo.remaining <= 0) {
        return {
          success: false,
          error: `Rate limit exceeded. You can vote again in ${Math.ceil((rateLimitInfo.resetTime - Date.now()) / 60000)} minutes.`,
          rateLimitInfo
        };
      }

      const session = await this.getVotingSession(sessionId);
      if (!session || !session.isActive || Date.now() > session.deadline) {
        return {
          success: false,
          error: 'Voting session is no longer active',
          rateLimitInfo
        };
      }

      // Validate option index
      if (optionIndex < 0 || optionIndex >= session.options.length) {
        return {
          success: false,
          error: 'Invalid voting option',
          rateLimitInfo
        };
      }

      // Remove previous vote if exists
      if (session.userVotes[userId] !== undefined) {
        const prevOption = session.userVotes[userId];
        session.votes[prevOption] = Math.max(0, (session.votes[prevOption] || 0) - 1);
      }

      // Record new vote
      session.userVotes[userId] = optionIndex;
      session.votes[optionIndex] = (session.votes[optionIndex] || 0) + 1;

      await this.saveVotingSession(session);
      
      // Update rate limiting
      const rateLimitKey = this.getKey(`${RATE_LIMIT_KEY_PREFIX}:vote:${userId}`);
      const currentCount = rateLimitInfo.total - rateLimitInfo.remaining;
      await this.context.redis.set(
        rateLimitKey, 
        (currentCount + 1).toString(), 
        { expiration: new Date(rateLimitInfo.resetTime) }
      );
      
      return {
        success: true,
        rateLimitInfo: await this.getRateLimitStatus(userId, 'vote')
      };
    }, 'recordVote');
  }

  async recordMoodVote(sessionId: string, userId: string, variable: string, value: number): Promise<{
    success: boolean;
    error?: string;
    rateLimitInfo?: any;
  }> {
    return this.retryOperation(async () => {
      // Get rate limit status first
      const rateLimitInfo = await this.getRateLimitStatus(userId, 'mood');
      
      if (rateLimitInfo.remaining <= 0) {
        return {
          success: false,
          error: `Rate limit exceeded. You can vote again in ${Math.ceil((rateLimitInfo.resetTime - Date.now()) / 60000)} minutes.`,
          rateLimitInfo
        };
      }

      const session = await this.getMoodVotingSession(sessionId);
      if (!session || !session.isActive || Date.now() > session.deadline) {
        return {
          success: false,
          error: 'Mood voting session is no longer active',
          rateLimitInfo
        };
      }

      // Validate variable and value
      const validVariable = session.variables.find(v => v.name === variable);
      if (!validVariable || value < validVariable.min || value > validVariable.max) {
        return {
          success: false,
          error: 'Invalid mood variable or value',
          rateLimitInfo
        };
      }

      if (!session.votes[userId]) {
        session.votes[userId] = {};
      }
      session.votes[userId][variable] = value;

      await this.saveMoodVotingSession(session);
      
      // Update rate limiting
      const rateLimitKey = this.getKey(`${RATE_LIMIT_KEY_PREFIX}:mood:${userId}`);
      const currentCount = rateLimitInfo.total - rateLimitInfo.remaining;
      await this.context.redis.set(
        rateLimitKey, 
        (currentCount + 1).toString(), 
        { expiration: new Date(rateLimitInfo.resetTime) }
      );
      
      return {
        success: true,
        rateLimitInfo: await this.getRateLimitStatus(userId, 'mood')
      };
    }, 'recordMoodVote');
  }

  // Enhanced voting results with better tie handling
  async getVotingWinner(sessionId: string): Promise<{ option: string; index: number } | null> {
    return this.retryOperation(async () => {
      const session = await this.getVotingSession(sessionId);
      if (!session) {
        console.warn(`No voting session found: ${sessionId}`);
        return null;
      }

      let maxVotes = -1;
      let winnerIndex = -1;
      const ties: number[] = [];

      // Find winner and detect ties
      for (const [index, votes] of Object.entries(session.votes)) {
        const voteCount = votes || 0;
        if (voteCount > maxVotes) {
          maxVotes = voteCount;
          winnerIndex = parseInt(index);
          ties.length = 0; // Clear ties
          ties.push(winnerIndex);
        } else if (voteCount === maxVotes && voteCount > 0) {
          ties.push(parseInt(index));
        }
      }

      // Handle ties with weighted random selection
      if (ties.length > 1) {
        // Use deterministic seed based on session ID for consistent tie-breaking
        const seed = deterministicHash(sessionId);
        winnerIndex = ties[Math.floor(seed * ties.length)];
        console.log(`Tie detected in session ${sessionId}, deterministically selected option ${winnerIndex}`);
      }

      // No votes cast - weighted random selection with fallback
      if (winnerIndex === -1 || maxVotes === 0) {
        const weights = session.options.map((_, i) => (session.votes[i] || 0) + 1);
        const totalWeight = weights.reduce((sum, w) => sum + w, 0);
        
        // Use session-based seed for consistency
        const seed = deterministicHash(sessionId);
        let random = seed * totalWeight;
        
        for (let i = 0; i < weights.length; i++) {
          random -= weights[i];
          if (random <= 0) {
            winnerIndex = i;
            break;
          }
        }
        
        if (winnerIndex === -1) {
          winnerIndex = Math.floor(seed * session.options.length);
        }
        
        console.log(`No votes in session ${sessionId}, deterministically selected option ${winnerIndex}`);
      }

      return {
        option: session.options[winnerIndex],
        index: winnerIndex
      };
    }, 'getVotingWinner');
  }

  async getMoodVotingResult(sessionId: string): Promise<MoodSettings> {
    return this.retryOperation(async () => {
      const session = await this.getMoodVotingSession(sessionId);
      const defaultMood: MoodSettings = { 
        happiness: 5, 
        energy: 5, 
        mystery: 5, 
        romance: 5, 
        darkness: 5, 
        nature: 5 
      };
      
      if (!session) {
        console.warn(`No mood voting session found: ${sessionId}, using defaults`);
        return defaultMood;
      }

      const result: MoodSettings = { ...defaultMood };
      const userCount = Object.keys(session.votes).length;

      if (userCount === 0) {
        console.log(`No mood votes in session ${sessionId}, using defaults`);
        return result;
      }

      // Calculate weighted average for each mood variable
      for (const variable of session.variables) {
        let total = 0;
        let count = 0;

        for (const userVotes of Object.values(session.votes)) {
          if (userVotes[variable.name] !== undefined) {
            total += userVotes[variable.name];
            count++;
          }
        }

        if (count > 0) {
          // Round to nearest integer, ensuring it stays within bounds
          const average = Math.round(total / count);
          result[variable.name as keyof MoodSettings] = Math.max(
            variable.min, 
            Math.min(variable.max, average)
          );
        }
      }

      console.log(`Mood voting result for ${sessionId}:`, result);
      return result;
    }, 'getMoodVotingResult');
  }

  // Enhanced cleanup with better error handling and logging
  async cleanupExpiredData(): Promise<{ cleaned: number; errors: number }> {
    let totalCleaned = 0;
    let totalErrors = 0;

    try {
      const patterns = [
        this.getKey(`${VOTING_KEY_PREFIX}:*`),
        this.getKey(`${MOOD_VOTING_KEY_PREFIX}:*`),
        this.getKey(`${RATE_LIMIT_KEY_PREFIX}:*`)
      ];

      for (const pattern of patterns) {
        try {
          const keys = await this.context.redis.keys(pattern);
          let cleanedCount = 0;
          let errorCount = 0;
          
          for (const key of keys) {
            try {
              const data = await this.context.redis.get(key);
              if (!data) {
                cleanedCount++;
              }
            } catch (keyError) {
              console.warn(`Error checking key ${key}:`, keyError);
              errorCount++;
            }
          }
          
          totalCleaned += cleanedCount;
          totalErrors += errorCount;
          
          if (cleanedCount > 0) {
            console.log(`Cleaned up ${cleanedCount} expired keys for pattern ${pattern}`);
          }
        } catch (patternError) {
          console.error(`Error cleaning pattern ${pattern}:`, patternError);
          totalErrors++;
        }
      }

      // Clean operation cache
      const now = Date.now();
      let cacheCleanedCount = 0;
      for (const [key, cached] of operationCache.entries()) {
        if (now - cached.timestamp > cached.ttl) {
          operationCache.delete(key);
          cacheCleanedCount++;
        }
      }
      
      if (cacheCleanedCount > 0) {
        console.log(`Cleaned up ${cacheCleanedCount} expired cache entries`);
      }

      return { cleaned: totalCleaned, errors: totalErrors };
    } catch (error) {
      console.error('Error cleaning up expired data:', error);
      return { cleaned: totalCleaned, errors: totalErrors + 1 };
    }
  }

  // Enhanced admin functions with validation and logging
  async setAdminOverride(key: string, value: any): Promise<void> {
    return this.retryOperation(async () => {
      if (!key || typeof key !== 'string') {
        throw new Error('Invalid admin override key');
      }
      
      const adminKey = this.getKey(`${ADMIN_KEY_PREFIX}:${key}`);
      await this.context.redis.set(
        adminKey, 
        JSON.stringify(value), 
        { expiration: new Date(Date.now() + 24 * 60 * 60 * 1000) }
      );
      
      console.log(`Admin override set: ${key}`, value);
    }, 'setAdminOverride');
  }

  async getAdminOverride(key: string): Promise<any> {
    return this.retryOperation(async () => {
      if (!key || typeof key !== 'string') {
        return null;
      }
      
      const adminKey = this.getKey(`${ADMIN_KEY_PREFIX}:${key}`);
      const data = await this.context.redis.get(adminKey);
      return data ? JSON.parse(data) : null;
    }, 'getAdminOverride');
  }
}