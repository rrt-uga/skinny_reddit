/**
 * Mock authentication for WebContainer development
 */
export class MockAuthManager {
  private static instance: MockAuthManager;
  private isAuthenticated = false;
  private mockUser = {
    id: 'mock_user_123',
    username: 'devvit_developer',
    isAdmin: true
  };

  static getInstance(): MockAuthManager {
    if (!MockAuthManager.instance) {
      MockAuthManager.instance = new MockAuthManager();
    }
    return MockAuthManager.instance;
  }

  async login(): Promise<{ success: boolean; message: string }> {
    // Simulate authentication process
    console.log('🔐 Mock Authentication Started');
    console.log('In a real environment, this would:');
    console.log('1. Open Reddit OAuth flow');
    console.log('2. Handle user consent');
    console.log('3. Store authentication tokens');
    
    // Simulate delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    this.isAuthenticated = true;
    
    return {
      success: true,
      message: 'Mock authentication successful! In production, use real Reddit OAuth.'
    };
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }

  getCurrentUser() {
    return this.isAuthenticated ? this.mockUser : null;
  }

  async logout(): Promise<void> {
    this.isAuthenticated = false;
    console.log('🔓 Mock user logged out');
  }
}