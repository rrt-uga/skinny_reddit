export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

export function validateKeyLine(keyLine: string): ValidationResult {
  if (!keyLine || typeof keyLine !== 'string') {
    return { isValid: false, error: 'Key line is required' };
  }
  
  if (keyLine.trim().length === 0) {
    return { isValid: false, error: 'Key line cannot be empty' };
  }
  
  if (keyLine.length > 200) {
    return { isValid: false, error: 'Key line must be under 200 characters' };
  }
  
  const words = keyLine.trim().split(/\s+/);
  if (words.length < 3) {
    return { isValid: false, error: 'Key line must contain at least 3 words' };
  }
  
  if (words.length > 15) {
    return { isValid: false, error: 'Key line must contain no more than 15 words' };
  }
  
  // Check for inappropriate content (basic filter)
  const inappropriateWords = ['spam', 'hate', 'abuse'];
  const lowerKeyLine = keyLine.toLowerCase();
  for (const word of inappropriateWords) {
    if (lowerKeyLine.includes(word)) {
      return { isValid: false, error: 'Key line contains inappropriate content' };
    }
  }
  
  return { isValid: true };
}

export function validateKeyWord(keyWord: string): ValidationResult {
  if (!keyWord || typeof keyWord !== 'string') {
    return { isValid: false, error: 'Key word is required' };
  }
  
  if (keyWord.trim().length === 0) {
    return { isValid: false, error: 'Key word cannot be empty' };
  }
  
  if (keyWord.length > 50) {
    return { isValid: false, error: 'Key word must be under 50 characters' };
  }
  
  // Should be a single word
  const words = keyWord.trim().split(/\s+/);
  if (words.length > 1) {
    return { isValid: false, error: 'Key word must be a single word' };
  }
  
  // Basic character validation
  if (!/^[a-zA-Z]+$/.test(keyWord.trim())) {
    return { isValid: false, error: 'Key word must contain only letters' };
  }
  
  return { isValid: true };
}

export function validateMoodValue(value: number, min: number = 1, max: number = 10): ValidationResult {
  if (typeof value !== 'number' || isNaN(value)) {
    return { isValid: false, error: 'Mood value must be a number' };
  }
  
  if (value < min || value > max) {
    return { isValid: false, error: `Mood value must be between ${min} and ${max}` };
  }
  
  if (!Number.isInteger(value)) {
    return { isValid: false, error: 'Mood value must be a whole number' };
  }
  
  return { isValid: true };
}

export function validateUserId(userId: string): ValidationResult {
  if (!userId || typeof userId !== 'string') {
    return { isValid: false, error: 'User ID is required' };
  }
  
  if (userId.trim().length === 0) {
    return { isValid: false, error: 'User ID cannot be empty' };
  }
  
  return { isValid: true };
}

export function validateVotingOptionIndex(index: number, maxOptions: number): ValidationResult {
  if (typeof index !== 'number' || isNaN(index)) {
    return { isValid: false, error: 'Option index must be a number' };
  }
  
  if (!Number.isInteger(index)) {
    return { isValid: false, error: 'Option index must be a whole number' };
  }
  
  if (index < 0 || index >= maxOptions) {
    return { isValid: false, error: `Option index must be between 0 and ${maxOptions - 1}` };
  }
  
  return { isValid: true };
}