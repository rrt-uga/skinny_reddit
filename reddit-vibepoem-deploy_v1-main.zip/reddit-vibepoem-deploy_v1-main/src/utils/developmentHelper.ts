// Development utilities for WebContainer environment
export class DevelopmentHelper {
  static logEnvironmentInfo(): void {
    console.log('🚀 Devvit Development Environment');
    console.log('================================');
    console.log(`Node.js: ${process.version}`);
    console.log(`Platform: ${process.platform}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    
    // Check if we're in WebContainer
    const isWebContainer = typeof window !== 'undefined' || 
                          process.env.WEBCONTAINER === 'true';
    
    if (isWebContainer) {
      console.log('🌐 WebContainer Environment Detected');
      console.log('   - Mock authentication enabled');
      console.log('   - Redis operations simulated');
      console.log('   - Reddit API calls mocked');
      console.log('');
      console.log('📋 Available Commands:');
      console.log('   npm run build    - Build the app');
      console.log('   npm run dev      - Start development server');
      console.log('   npm run login    - Show authentication info');
      console.log('   npm run test     - Run tests');
      console.log('');
      console.log('🔧 For production deployment:');
      console.log('   Set up local development environment');
    } else {
      console.log('💻 Local Environment Detected');
      console.log('   - Full Reddit authentication available');
      console.log('   - Real Redis operations');
      console.log('   - Live Reddit API access');
    }
    console.log('================================');
  }

  static async validateDevvitSetup(): Promise<{
    isValid: boolean;
    issues: string[];
    suggestions: string[];
  }> {
    const issues: string[] = [];
    const suggestions: string[] = [];

    // Check devvit.yaml
    try {
      const fs = await import('fs');
      const yaml = fs.readFileSync('devvit.yaml', 'utf8');
      if (!yaml.includes('capabilities:')) {
        issues.push('devvit.yaml missing capabilities section');
      }
      if (!yaml.includes('redis')) {
        suggestions.push('Consider adding redis capability for data persistence');
      }
    } catch (error) {
      issues.push('devvit.yaml not found or unreadable');
    }

    // Check TypeScript config
    try {
      const fs = await import('fs');
      const tsconfig = fs.readFileSync('tsconfig.json', 'utf8');
      if (!tsconfig.includes('@devvit/public-api')) {
        suggestions.push('Update tsconfig.json jsxImportSource to @devvit/public-api');
      }
    } catch (error) {
      suggestions.push('Create tsconfig.json for better TypeScript support');
    }

    return {
      isValid: issues.length === 0,
      issues,
      suggestions
    };
  }

  static generateMockData() {
    return {
      poems: [
        {
          id: '2025-01-01',
          date: '2025-01-01',
          keyLine: 'In the gentle whisper of dawn,',
          keyWord: 'whisper',
          mood: { happiness: 7, energy: 5, mystery: 4, romance: 6, darkness: 2, nature: 8 },
          lines: [
            'In the gentle whisper of dawn,',
            'whisper,',
            'dance',
            'through',
            'light',
            'whisper,',
            'beneath',
            'radiant,',
            'whisper,',
            'serene',
            'In the gentle whisper of dawn.'
          ],
          imagePrompt: 'gentle dawn whisper, artistic, poetic, dreamy, bright, joyful, warm colors, natural, organic, landscape, digital art, high quality',
          isComplete: true,
          createdAt: Date.now() - 86400000
        }
      ],
      votingSessions: {
        'keyline': {
          options: [
            'In the gentle whisper of dawn,',
            'Where shadows meet light in silent dance,',
            'Through ancient dreams and whispered hopes',
            'Beyond the veil lies hidden truth',
            'Within tender moments, hearts flutter'
          ],
          votes: { 0: 5, 1: 3, 2: 2, 3: 1, 4: 4 }
        }
      }
    };
  }
}