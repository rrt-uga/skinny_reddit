export interface SkinnyPoem {
  id: string;
  date: string;
  keyLine: string;
  keyWord: string;
  mood: MoodSettings;
  lines: string[];
  imagePrompt: string;
  isComplete: boolean;
  createdAt: number;
}

export interface VotingSession {
  id: string;
  phase: VotingPhase;
  options: string[];
  votes: Record<string, number>; // optionIndex -> voteCount
  userVotes: Record<string, number>; // userId -> optionIndex
  deadline: number;
  isActive: boolean;
  poemId: string;
}

export interface MoodVotingSession {
  id: string;
  variables: MoodVariable[];
  votes: Record<string, Record<string, number>>; // userId -> variableName -> value
  deadline: number;
  isActive: boolean;
  poemId: string;
}

export interface MoodVariable {
  name: string;
  label: string;
  min: number;
  max: number;
}

export interface MoodSettings {
  happiness: number;
  energy: number;
  mystery: number;
  romance: number;
  darkness: number;
  nature: number;
}

export type VotingPhase = 'keyline' | 'keyword' | 'mood' | 'generation' | 'complete';

export interface WordOption {
  word: string;
  type: 'verb' | 'preposition' | 'noun' | 'adjective' | 'adverb';
}

export interface PoemLine {
  position: number;
  word: string;
  type: string;
  punctuation: string;
}