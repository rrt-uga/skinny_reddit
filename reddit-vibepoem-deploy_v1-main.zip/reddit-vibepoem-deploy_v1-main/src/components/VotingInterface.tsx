import { Devvit } from '@devvit/public-api';
import { VotingSession, MoodVotingSession, MoodVariable } from '../types.js';
import { LoadingState, ErrorState } from './LoadingState.js';

interface VotingInterfaceProps {
  session: VotingSession;
  userVote?: number;
  onVote: (optionIndex: number) => void;
  timeRemaining: string;
  isLoading?: boolean;
  error?: string;
  rateLimitInfo?: {
    remaining: number;
    total: number;
    resetTime: number;
    isNearLimit: boolean;
  };
}

export function VotingInterface({ 
  session, 
  userVote, 
  onVote, 
  timeRemaining, 
  isLoading, 
  error,
  rateLimitInfo 
}: VotingInterfaceProps): JSX.Element {
  if (error) {
    return <ErrorState error={error} />;
  }

  if (isLoading) {
    return <LoadingState message={
      session?.phase === 'keyline' 
        ? 'Loading key line voting options...' 
        : 'Loading key word voting options...'
    } />;
  }

  const totalVotes = Object.values(session.votes).reduce((sum, count) => sum + count, 0);
  const isExpired = Date.now() > session.deadline;

  return (
    <vstack gap="medium" padding="medium" backgroundColor="neutral-background-weak">
      <vstack gap="small">
        <text size="large" weight="bold">
          🗳️ {session.phase === 'keyline' ? 'Vote for Key Line' : 'Vote for Key Word'}
        </text>
        <hstack gap="small" alignment="center middle">
          <text size="small" color="neutral-content-weak" grow>
            {isExpired ? 'Voting ended' : `${timeRemaining} (ET)`}
          </text>
          <text size="small" color="neutral-content-weak">
            {totalVotes} vote{totalVotes !== 1 ? 's' : ''} cast
          </text>
        </hstack>
      </vstack>

      {/* Rate limit warning */}
      {rateLimitInfo && rateLimitInfo.isNearLimit && !isExpired && (
        <text size="small" color="orange" alignment="center middle">
          ⚠️ You have {rateLimitInfo.remaining} vote{rateLimitInfo.remaining !== 1 ? 's' : ''} remaining this hour
        </text>
      )}

      {isExpired && (
        <text size="small" color="orange" alignment="center middle">
          ⏰ Voting has ended. Results are being processed.
        </text>
      )}

      <vstack gap="small">
        {session.options.map((option, index) => {
          const voteCount = session.votes[index] || 0;
          const percentage = totalVotes > 0 ? Math.round((voteCount / totalVotes) * 100) : 0;
          const isSelected = userVote === index;
          const isWinning = voteCount > 0 && voteCount === Math.max(...Object.values(session.votes));

          return (
            <vstack key={index} gap="xsmall">
              <button
                onPress={() => !isExpired && onVote(index)}
                appearance={isSelected ? "primary" : "secondary"}
                size="medium"
                disabled={isExpired}
              >
                <hstack gap="small" alignment="center middle">
                  <text wrap grow alignment="start middle">
                    {option}
                  </text>
                  {isWinning && totalVotes > 0 && (
                    <text size="small">🏆</text>
                  )}
                </hstack>
              </button>
              
              {voteCount > 0 && (
                <hstack gap="small" alignment="center middle" padding="xsmall">
                  <text size="small" color="neutral-content-weak">
                    {voteCount} vote{voteCount !== 1 ? 's' : ''} ({percentage}%)
                  </text>
                  <spacer grow />
                  <hstack gap="none">
                    {Array.from({ length: Math.min(10, Math.ceil(percentage / 10)) }, (_, i) => (
                      <text key={i} size="small" color="blue">▓</text>
                    ))}
                    {Array.from({ length: Math.max(0, 10 - Math.ceil(percentage / 10)) }, (_, i) => (
                      <text key={i} size="small" color="neutral-content-weak">░</text>
                    ))}
                  </hstack>
                </hstack>
              )}
            </vstack>
          );
        })}
      </vstack>

      {userVote !== undefined && !isExpired && (
        <text size="small" color="green" alignment="center middle">
          ✓ You voted for: "{session.options[userVote]}"
        </text>
      )}

      {totalVotes === 0 && !isExpired && (
        <text size="small" color="neutral-content-weak" alignment="center middle">
          Be the first to vote! Your choice will help shape today's poem.
        </text>
      )}

      {/* Rate limit status */}
      {rateLimitInfo && !isExpired && (
        <text size="small" color="neutral-content-weak" alignment="center middle">
          Votes remaining this hour: {rateLimitInfo.remaining}/{rateLimitInfo.total}
        </text>
      )}
    </vstack>
  );
}

interface MoodVotingInterfaceProps {
  session: MoodVotingSession;
  userVotes: Record<string, number>;
  onVote: (variable: string, value: number) => void;
  timeRemaining: string;
  isLoading?: boolean;
  error?: string;
  rateLimitInfo?: {
    remaining: number;
    total: number;
    resetTime: number;
    isNearLimit: boolean;
  };
}

export function MoodVotingInterface({ 
  session, 
  userVotes, 
  onVote, 
  timeRemaining, 
  isLoading, 
  error,
  rateLimitInfo 
}: MoodVotingInterfaceProps): JSX.Element {
  if (error) {
    return <ErrorState error={error} />;
  }

  if (isLoading) {
    return <LoadingState message="Loading mood voting interface..." />;
  }

  const totalVoters = Object.keys(session.votes).length;
  const isExpired = Date.now() > session.deadline;

  return (
    <vstack gap="medium" padding="medium" backgroundColor="neutral-background-weak">
      <vstack gap="small">
        <text size="large" weight="bold">
          🎭 Vote for Poem Mood
        </text>
        <hstack gap="small" alignment="center middle">
          <text size="small" color="neutral-content-weak" grow>
            {isExpired ? 'Voting ended' : `${timeRemaining} (ET)`}
          </text>
          <text size="small" color="neutral-content-weak">
            {totalVoters} participant{totalVoters !== 1 ? 's' : ''}
          </text>
        </hstack>
        <text size="small" color="neutral-content" wrap>
          Set the mood for today's poem using the sliders below (1-10 scale)
        </text>
      </vstack>

      {/* Rate limit warning */}
      {rateLimitInfo && rateLimitInfo.isNearLimit && !isExpired && (
        <text size="small" color="orange" alignment="center middle">
          ⚠️ You have {rateLimitInfo.remaining} mood vote{rateLimitInfo.remaining !== 1 ? 's' : ''} remaining this hour
        </text>
      )}

      {isExpired && (
        <text size="small" color="orange" alignment="center middle">
          ⏰ Mood voting has ended. The poem is being generated.
        </text>
      )}

      <vstack gap="medium">
        {session.variables.map((variable) => {
          const userValue = userVotes[variable.name] || 5;
          const moodEmojis: Record<string, string> = {
            happiness: '😊',
            energy: '⚡',
            mystery: '🌙',
            romance: '💕',
            darkness: '🖤',
            nature: '🌿'
          };
          
          return (
            <vstack key={variable.name} gap="small">
              <hstack gap="small" alignment="center middle">
                <text weight="bold" grow>
                  {moodEmojis[variable.name] || '🎨'} {variable.label}
                </text>
                <text size="small" color="neutral-content-weak">
                  {userValue}/{variable.max}
                </text>
              </hstack>
              
              <hstack gap="xsmall" alignment="center middle" wrap>
                {Array.from({ length: variable.max - variable.min + 1 }, (_, i) => {
                  const value = variable.min + i;
                  const isSelected = userValue === value;
                  
                  return (
                    <button
                      key={value}
                      onPress={() => !isExpired && onVote(variable.name, value)}
                      appearance={isSelected ? "primary" : "secondary"}
                      size="small"
                      disabled={isExpired}
                    >
                      {value}
                    </button>
                  );
                })}
              </hstack>
              
              {/* Visual indicator with accessibility */}
              <hstack gap="none" alignment="center middle">
                {Array.from({ length: variable.max }, (_, i) => {
                  const filled = i < userValue;
                  return (
                    <text key={i} size="small" color={filled ? "blue" : "neutral-content-weak"}>
                      {filled ? '●' : '○'}
                    </text>
                  );
                })}
              </hstack>
              
              {/* Accessibility text */}
              <text size="small" color="neutral-content-weak" alignment="center middle">
                {variable.label} level: {userValue} out of {variable.max}
              </text>
            </vstack>
          );
        })}
      </vstack>

      {Object.keys(userVotes).length > 0 && !isExpired && (
        <text size="small" color="green" alignment="center middle">
          ✓ Your mood preferences have been recorded
        </text>
      )}

      {totalVoters === 0 && !isExpired && (
        <text size="small" color="neutral-content-weak" alignment="center middle" wrap>
          Be the first to set the mood! Your preferences will influence the poem's emotional tone.
        </text>
      )}

      <text size="small" color="neutral-content-weak" alignment="center middle" wrap>
        Your votes will be averaged with other participants to determine the final mood.
      </text>

      {/* Rate limit status */}
      {rateLimitInfo && !isExpired && (
        <text size="small" color="neutral-content-weak" alignment="center middle">
          Mood votes remaining this hour: {rateLimitInfo.remaining}/{rateLimitInfo.total}
        </text>
      )}
    </vstack>
  );
}