import { Devvit } from '@devvit/public-api';

interface LoadingStateProps {
  message?: string;
  size?: 'small' | 'medium' | 'large';
  showProgress?: boolean;
  progressSteps?: string[];
  currentStep?: number;
}

export function LoadingState({ 
  message = 'Loading...', 
  size = 'medium',
  showProgress = false,
  progressSteps = [],
  currentStep = 0
}: LoadingStateProps): JSX.Element {
  const textSize = size === 'small' ? 'small' : size === 'large' ? 'large' : 'medium';
  
  return (
    <vstack gap="medium" padding="medium" alignment="center middle">
      <text size={textSize} color="neutral-content-weak">
        ⏳ {message}
      </text>
      
      {showProgress && progressSteps.length > 0 && (
        <vstack gap="small" alignment="center middle">
          {progressSteps.map((step, index) => {
            const isCompleted = index < currentStep;
            const isCurrent = index === currentStep;
            const isPending = index > currentStep;
            
            let color = "neutral-content-weak";
            let icon = "○";
            
            if (isCompleted) {
              color = "green";
              icon = "✓";
            } else if (isCurrent) {
              color = "blue";
              icon = "⏳";
            }
            
            return (
              <hstack key={index} gap="small" alignment="center middle">
                <text size="small" color={color}>{icon}</text>
                <text size="small" color={color}>{step}</text>
              </hstack>
            );
          })}
        </vstack>
      )}
    </vstack>
  );
}

interface ErrorStateProps {
  error: string;
  onRetry?: () => void;
  showRetry?: boolean;
  errorCode?: string;
  isTemporary?: boolean;
}

export function ErrorState({ 
  error, 
  onRetry, 
  showRetry = true, 
  errorCode,
  isTemporary = false 
}: ErrorStateProps): JSX.Element {
  return (
    <vstack gap="medium" padding="medium" alignment="center middle">
      <text size="medium" color="red">
        ❌ {error}
      </text>
      
      {errorCode && (
        <text size="small" color="neutral-content-weak">
          Error Code: {errorCode}
        </text>
      )}
      
      {isTemporary && (
        <text size="small" color="orange" alignment="center middle" wrap>
          This appears to be a temporary issue. Please try again in a moment.
        </text>
      )}
      
      {showRetry && onRetry && (
        <button onPress={onRetry} appearance="secondary" size="small">
          Try Again
        </button>
      )}
      
      <text size="small" color="neutral-content-weak" alignment="center middle" wrap>
        If this problem persists, please contact the subreddit moderators.
      </text>
    </vstack>
  );
}

interface EmptyStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: string;
}

export function EmptyState({ 
  title, 
  description, 
  actionLabel, 
  onAction,
  icon = "📭"
}: EmptyStateProps): JSX.Element {
  return (
    <vstack gap="medium" padding="large" alignment="center middle">
      <text size="xlarge">{icon}</text>
      <text size="large" weight="bold" color="neutral-content-weak">
        {title}
      </text>
      <text size="medium" color="neutral-content-weak" alignment="center middle" wrap>
        {description}
      </text>
      {actionLabel && onAction && (
        <button onPress={onAction} appearance="primary" size="medium">
          {actionLabel}
        </button>
      )}
    </vstack>
  );
}

interface SuccessStateProps {
  title: string;
  description: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function SuccessState({ 
  title, 
  description, 
  actionLabel, 
  onAction 
}: SuccessStateProps): JSX.Element {
  return (
    <vstack gap="medium" padding="medium" alignment="center middle">
      <text size="large" color="green">
        ✅ {title}
      </text>
      <text size="medium" color="neutral-content" alignment="center middle" wrap>
        {description}
      </text>
      {actionLabel && onAction && (
        <button onPress={onAction} appearance="primary" size="medium">
          {actionLabel}
        </button>
      )}
    </vstack>
  );
}