import { Devvit } from '@devvit/public-api';
import { SkinnyPoem } from '../types.js';
import { LoadingState, ErrorState, EmptyState } from './LoadingState.js';
import { formatEasternTime } from '../utils/timeUtils.js';

interface PoemDisplayProps {
  poem: SkinnyPoem;
  showMetadata?: boolean;
  compact?: boolean;
}

export function PoemDisplay({ poem, showMetadata = true, compact = false }: PoemDisplayProps): JSX.Element {
  const moodEmojis = {
    happiness: '😊',
    energy: '⚡',
    mystery: '🌙',
    romance: '💕',
    darkness: '🖤',
    nature: '🌿'
  };

  const padding = compact ? "small" : "medium";
  const titleSize = compact ? "medium" : "large";
  const lineSize = compact ? "small" : "medium";

  // Format date in Eastern Time
  const poemDate = new Date(poem.date);
  const easternDateString = poemDate.toLocaleDateString("en-US", {
    timeZone: "America/New_York",
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const createdAtEastern = formatEasternTime(new Date(poem.createdAt));

  return (
    <vstack gap="medium" padding={padding} backgroundColor="neutral-background-weak">
      {showMetadata && (
        <vstack gap="small">
          <text size={titleSize} weight="bold">
            📜 Daily Skinny Poem - {easternDateString}
          </text>
          <hstack gap="small" wrap alignment="start middle">
            {Object.entries(poem.mood).map(([key, value]) => {
              const emoji = moodEmojis[key as keyof typeof moodEmojis];
              const intensity = value > 7 ? 'high' : value > 4 ? 'medium' : 'low';
              const color = intensity === 'high' ? 'blue' : intensity === 'medium' ? 'neutral-content' : 'neutral-content-weak';
              
              return (
                <text key={key} size="small" color={color}>
                  {emoji} {key}: {value}/10
                </text>
              );
            })}
          </hstack>
        </vstack>
      )}

      <vstack gap="small" alignment="center middle" padding="medium" backgroundColor="white">
        {poem.lines.map((line, index) => {
          const isKeyLine = index === 0 || index === 10;
          const isKeyWord = index === 1 || index === 5 || index === 8;
          
          let textColor = "neutral-content-weak";
          let weight: "regular" | "bold" = "regular";
          let size = lineSize;
          
          if (isKeyLine) {
            textColor = "neutral-content";
            weight = "bold";
            size = compact ? "medium" : "large";
          } else if (isKeyWord) {
            textColor = "blue";
            weight = "bold";
          }
          
          return (
            <text
              key={index}
              size={size}
              weight={weight}
              color={textColor}
              alignment="center middle"
              wrap
            >
              {line}
            </text>
          );
        })}
      </vstack>

      {showMetadata && poem.imagePrompt && !compact && (
        <vstack gap="small">
          <text size="small" weight="bold">💭 Image Concept:</text>
          <text size="small" color="neutral-content-weak" wrap>
            {poem.imagePrompt}
          </text>
        </vstack>
      )}

      {showMetadata && !compact && (
        <text size="small" color="neutral-content-weak" alignment="center middle">
          Created collaboratively by the community • {createdAtEastern} ET
        </text>
      )}
    </vstack>
  );
}

interface PoemArchiveProps {
  poems: SkinnyPoem[];
  onSelectPoem: (poem: SkinnyPoem) => void;
  isLoading?: boolean;
  error?: string;
}

export function PoemArchive({ poems, onSelectPoem, isLoading, error }: PoemArchiveProps): JSX.Element {
  if (error) {
    return <ErrorState error={error} />;
  }

  if (isLoading) {
    return <LoadingState message="Loading poem archive..." />;
  }

  if (poems.length === 0) {
    return (
      <EmptyState
        title="📚 No Poems Yet"
        description="The poem archive is empty. Check back after 9 PM ET for the first daily poem!"
      />
    );
  }

  const moodEmojis = {
    happiness: '😊',
    energy: '⚡',
    mystery: '🌙',
    romance: '💕',
    darkness: '🖤',
    nature: '🌿'
  };

  return (
    <vstack gap="medium" padding="medium">
      <text size="large" weight="bold">
        📚 Poem Archive ({poems.length} poem{poems.length !== 1 ? 's' : ''})
      </text>
      
      <vstack gap="small">
        {poems.slice(0, 20).map((poem) => {
          const date = new Date(poem.date);
          const easternDateString = date.toLocaleDateString("en-US", {
            timeZone: "America/New_York",
            month: 'short',
            day: 'numeric',
            year: 'numeric'
          });
          const preview = poem.keyLine.length > 40 ? poem.keyLine.substring(0, 40) + '...' : poem.keyLine;
          const statusIcon = poem.isComplete ? '✅' : '⏳';
          const statusText = poem.isComplete ? 'Complete' : 'In Progress';
          
          return (
            <button
              key={poem.id}
              onPress={() => onSelectPoem(poem)}
              appearance="secondary"
              size="medium"
            >
              <vstack gap="xsmall" alignment="start middle">
                <hstack gap="small" alignment="center middle">
                  <text weight="bold" grow alignment="start middle">
                    {easternDateString}
                  </text>
                  <text size="small" color="neutral-content-weak">
                    {statusIcon} {statusText}
                  </text>
                </hstack>
                <text size="small" color="neutral-content-weak" alignment="start middle" wrap>
                  "{preview}"
                </text>
                {poem.isComplete && (
                  <hstack gap="small" alignment="start middle" wrap>
                    {Object.entries(poem.mood).slice(0, 3).map(([key, value]) => {
                      const emoji = moodEmojis[key as keyof typeof moodEmojis];
                      return (
                        <text key={key} size="small" color="neutral-content-weak">
                          {emoji}{value}
                        </text>
                      );
                    })}
                  </hstack>
                )}
              </vstack>
            </button>
          );
        })}
        
        {poems.length > 20 && (
          <text size="small" color="neutral-content-weak" alignment="center middle">
            Showing latest 20 poems
          </text>
        )}
      </vstack>
    </vstack>
  );
}