import { Devvit } from '@devvit/public-api';

interface BoltBadgeProps {
  variant?: 'default' | 'compact' | 'minimal';
  position?: 'top' | 'bottom';
  showText?: boolean;
}

export function BoltBadge({ 
  variant = 'default', 
  position = 'bottom',
  showText = true 
}: BoltBadgeProps): JSX.Element {
  const getBadgeContent = () => {
    switch (variant) {
      case 'compact':
        return showText ? '⚡ Built with Bolt.new' : '⚡';
      case 'minimal':
        return '⚡';
      default:
        return showText ? '⚡ Built with Bolt.new' : '⚡ Bolt.new';
    }
  };

  const getBadgeSize = () => {
    switch (variant) {
      case 'compact':
        return 'small';
      case 'minimal':
        return 'small';
      default:
        return 'medium';
    }
  };

  const getBadgeColor = () => {
    return 'neutral-content-weak';
  };

  return (
    <hstack 
      gap="xsmall" 
      alignment="center middle" 
      padding={variant === 'minimal' ? 'xsmall' : 'small'}
    >
      <text 
        size={getBadgeSize()} 
        color={getBadgeColor()}
        alignment="center middle"
      >
        {getBadgeContent()}
      </text>
    </hstack>
  );
}

interface PoweredByBoltProps {
  compact?: boolean;
}

export function PoweredByBolt({ compact = false }: PoweredByBoltProps): JSX.Element {
  return (
    <vstack gap="xsmall" alignment="center middle" padding="small">
      <hstack gap="xsmall" alignment="center middle">
        <text size="small" color="neutral-content-weak">
          ⚡
        </text>
        <text size="small" color="neutral-content-weak">
          {compact ? 'Built with Bolt.new' : 'Powered by Bolt.new'}
        </text>
      </hstack>
      {!compact && (
        <text size="small" color="neutral-content-weak" alignment="center middle">
          AI-powered full-stack development
        </text>
      )}
    </vstack>
  );
}

interface BoltFooterProps {
  showDivider?: boolean;
}

export function BoltFooter({ showDivider = true }: BoltFooterProps): JSX.Element {
  return (
    <vstack gap="small" alignment="center middle">
      {showDivider && (
        <spacer size="small" />
      )}
      <hstack gap="small" alignment="center middle" padding="small">
        <text size="small" color="neutral-content-weak">
          ⚡ Built with
        </text>
        <text size="small" color="blue" weight="bold">
          Bolt.new
        </text>
      </hstack>
    </vstack>
  );
}